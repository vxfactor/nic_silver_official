# Workspace Tune-Up Kit: the 30-minute setup

One install path, ordered by payoff. Each step says what you get, what to do, and how to check it worked. Total time: about 30 minutes. You need: a Claude Code workspace (a folder with a `CLAUDE.md` or `.claude/` directory) and Python 3.9 or newer (`python3 --version` to check).

Nothing in this kit calls the internet, needs an API key, or sends anything anywhere. It is gates and patterns, installed locally.

## Before you start (2 min)

Unzip the kit next to your workspace, not inside it. You will copy files in, one step at a time.

If you ran the free Workspace Health Check, keep your scorecard open. Each step below names the flags it clears. Re-run the check at the end and watch the score move; that is your receipt.

## Step 1: the guardrail hook (5 min) | clears SEC-01

**What you get:** your AI physically cannot run a wipe-everything command, force-push over your work, or send an unapproved email. A written rule is a polite request; this fires before the command runs and blocks it.

1. Copy `hooks/guardrail_check.py` into your workspace at `.claude/hooks/`.
2. Open it and set `OWNER_EMAIL` to your address. Add any folders you never want deleted to `PROTECTED_PATHS`.
3. Merge the `PreToolUse` "Bash" entry from `settings-snippet.json` into `.claude/settings.json`. If you have no hooks yet, copy the whole block.
4. Restart Claude Code (hooks load at session start).

**Check:** ask Claude to run `rm -rf test-folder`. It should be blocked with a message from the guardrail, not a polite refusal.

## Step 2: the security nudge (3 min) | helps SEC-02, SEC-07

**What you get:** every time the AI writes code containing a risky pattern (a hardcoded key, eval on outside input, shell injection), it gets warned at write time. Warns, never blocks, so it cannot break your flow.

1. Copy `hooks/security_check.py` into `.claude/hooks/`.
2. Merge the `PreToolUse` "Write|Edit|MultiEdit" entry from `settings-snippet.json`.
3. Restart Claude Code.

**Check:** ask Claude to write a file containing a fake key like `sk-ant-api-test123456789012345678901234`. The nudge should appear in the session.

## Step 3: the skill validator (4 min) | clears HYG-01, HYG-02, helps SPD-03

**What you get:** every skill the AI writes introduces itself properly (name + description), stays under the size cap, and gets nudged to declare which model it needs. Skills without metadata never get picked; skills without model routing run on the most expensive model.

1. Copy `lib/validate_skill.py` into `.claude/lib/` (create the folder if needed).
2. Copy `hooks/skill_md_validate.py` into `.claude/hooks/`.
3. Merge the `PostToolUse` entry from `settings-snippet.json`. Restart.

**Check:** `python3 .claude/lib/validate_skill.py --all` lists every skill with its errors and warnings. Fix the errors; they are all small.

## Step 4: model routing (5 min) | clears SPD-03

**What you get:** cheap work runs on cheap models. A skill that renames files does not need the model that costs 25x more.

1. Copy `args/model-routing.yaml` into your workspace (`args/` or anywhere you keep config).
2. Open your five most-used skills. Add one line to each SKILL.md frontmatter: `tier: quick` (mechanical work), `tier: auto` (drafting), or `tier: deep` (judgment). The YAML file maps tiers to models and explains each.
3. Anything you skip just keeps running on the default model; the validator from Step 3 will keep reminding you.

**Check:** the spend dashboard (Step 6) shows model share per skill; watch the expensive model's share drop over the next week.

## Step 5: the send gate (4 min) | hardens outbound actions

**What you get:** any outbound action (email, post, payment) requires a human to see the full payload and type APPROVE EMAIL (or APPROVE POST, APPROVE PAYMENT) before it can fire. One wrong send to a real customer costs more than a year of token savings.

1. Copy `lib/send_gate.py` into `.claude/lib/`.
2. Run the demo: `python3 .claude/lib/send_gate.py`. Type the approval phrase when asked. Thirty seconds, and you have seen the whole mechanism.
3. Wire it into any script of yours that sends: the send function refuses unless `consume_approval(...)` returns True. The integration contract with a copy-paste example is in `lib/README-send-gate.md`.
4. Add `.claude/.action-approval/` to your `.gitignore`.

The guardrail hook from Step 1 already watches the same token directory, so ungated send scripts get blocked at the hook level too. Two layers, same key.

## Step 6: the spend dashboard (3 min) | clears the "flying blind" problem

**What you get:** one page showing what your AI actually costs: per day, per model, per project, per skill, cache hit rate, and the five most expensive sessions. Estimates at list prices; on a subscription it shows the value you consumed.

1. Copy `scripts/spend_dashboard.py` anywhere in your workspace.
2. Run: `python3 scripts/spend_dashboard.py --days 30`
3. The page opens in your browser. Re-run it monthly; trends matter more than snapshots.

**Check:** the "where this setup falls short" section at the bottom. Those flags are your next month's to-do list.

## Step 7: the skill-vet gate (5 min) | clears SEC-04, SEC-05, SEC-07

**What you get:** a quarantine and scan step between "found a skill on GitHub" and "installed it". Third-party skills are the most likely way a real attack reaches your workspace.

The `skill-vet/` folder inside this kit is its own component with its own README and self-test. Follow its install (copy skill + agent + hook, merge its settings entries), then run `python3 test/run_self_test.py` and confirm all checks pass before trusting it.

## Step 8: the pattern docs (read over coffee, apply over a week)

The `docs/` folder holds the patterns that cut our own running costs hardest. In payoff order:

1. `claude-md-tuner.md`: your instruction file loads on every session; this is the 20-minute trim that pays on every task forever. Clears SPD-01, SPD-02.
2. `lazy-loading.md`: plug-ins announce all their tools before you type a word; this is the audit. Clears SPD-04.
3. `context-fork-skill-chaining.md`: the pattern behind our measured 85% token cut on one daily pipeline. For your longest skills. Clears SPD-05.
4. `prompt-injection-defense.md`: if your AI reads email or web pages, read this today. Clears SEC-08.
5. `cross-agent-compatibility.md`: the mirror file that lets your business keep running if your AI vendor has a bad day. Clears RES-01, RES-02. The drift checker (`lib/check_agents_sync.py`) goes into `.claude/lib/` if you adopt it.

## Done: take the receipt

Re-run the free health check:

```bash
python3 healthcheck.py
```

Your score should be well above where it started, and every remaining flag now has a named fix you own. Re-run the spend dashboard monthly and the health check after any big workspace change.

Stuck on a step, or want this installed and tuned for you instead? That is exactly what the audit is for. Book it from the link in your kit receipt.
