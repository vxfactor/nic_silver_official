#!/usr/bin/env python3
"""
skill_vet.py — Layer 1 deterministic scanner for third-party skill/plugin/MCP repos.

Quarantine-first supply-chain gate. A downloaded repo is scanned IN QUARANTINE
(active/quarantine/<slug>/) before anything is allowed near .claude/skills/,
.claude/plugins/, .agents/skills/, or .mcp.json. The PreToolUse guardrail hook
(guardrail_check.py check_quarantine_install) blocks install commands unless a
fresh approval token written by this script exists.

Verdict model:  PASS (exit 0)  <  REVIEW (exit 1)  <  BLOCK (exit 2)
Worst finding wins. BLOCK is never installable through the tooling. REVIEW
requires a human to read the findings and approve verbatim. The Layer 2 LLM
reviewer can only ESCALATE a verdict (passed via `approve --llm-verdict`),
never downgrade — codified here, not in prose.

Usage:
    skill_vet.py scan <quarantine_dir> [--json] [--config <vet-rules.yaml>]
    skill_vet.py approve <slug> [--llm-verdict PASS|REVIEW|BLOCK] [--approved-by-human]
    skill_vet.py install <slug> --dest <path>
    skill_vet.py hash <dir>

Standalone-safe: imports workspace libs (secret_scan PATTERNS, validate_skill)
when present, falls back to vendored copies otherwise. Stdlib + optional pyyaml.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import math
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_DIR = SCRIPT_DIR.parent
DEFAULT_CONFIG = SKILL_DIR / "config" / "vet-rules.yaml"

# Workspace root when running inside the Silver AI workspace; falls back to
# cwd for standalone/template installs.
_workspace_candidate = SCRIPT_DIR.parents[3] if len(SCRIPT_DIR.parents) >= 4 else Path.cwd()
WORKSPACE = _workspace_candidate if (_workspace_candidate / ".claude").exists() else Path.cwd()

SEVERITY_ORDER = {"PASS": 0, "INFO": 0, "REVIEW": 1, "BLOCK": 2}
EXIT_FOR_VERDICT = {"PASS": 0, "REVIEW": 1, "BLOCK": 2}

# --- workspace lib imports with vendored fallbacks --------------------------

sys.path.insert(0, str(WORKSPACE / ".claude" / "lib"))

try:
    from secret_scan import PATTERNS as SECRET_PATTERNS, DOC_EXAMPLE_KEYS  # type: ignore
except ImportError:
    # Vendored from .claude/lib/secret_scan.py — keep in sync.
    SECRET_PATTERNS = {
        "anthropic_api_key":  re.compile(r"\bsk-ant-(?:api|admin|train)[0-9a-zA-Z\-_]{20,}"),
        "openai_api_key":     re.compile(r"\bsk-(?:proj|live|test)?-?[A-Za-z0-9_\-]{32,}"),
        "openai_legacy_key":  re.compile(r"\bsk-[A-Za-z0-9]{48,}\b"),
        "stripe_secret_live": re.compile(r"\b(?:sk|rk)_live_[A-Za-z0-9]{20,}"),
        "stripe_secret_test": re.compile(r"\b(?:sk|rk)_test_[A-Za-z0-9]{20,}"),
        "github_token":       re.compile(r"\bgh[opsu]_[A-Za-z0-9]{36,}"),
        "github_pat":         re.compile(r"\bgithub_pat_[A-Za-z0-9_]{60,}"),
        "slack_bot_token":    re.compile(r"\bxoxb-[0-9]{10,}-[0-9]{10,}-[A-Za-z0-9]{20,}"),
        "slack_user_token":   re.compile(r"\bxoxp-[0-9]{10,}-[0-9]{10,}-[0-9]{10,}-[A-Za-z0-9]{20,}"),
        "google_api_key":     re.compile(r"\bAIza[0-9A-Za-z\-_]{35}\b"),
        "aws_access_key":     re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
        "aws_secret_key":     re.compile(r"(?i)aws.{0,20}secret.{0,20}[\"'`][A-Za-z0-9/+=]{40}[\"'`]"),
        "private_key_pem":    re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----"),
        "convex_deploy_key":  re.compile(r"\bprod:[a-z0-9\-]+\|[A-Za-z0-9]{40,}"),
    }
    DOC_EXAMPLE_KEYS = ("AKIAIOSFODNN7EXAMPLE", "wJalrXUtnFEMI/K7MDENG")

try:
    from validate_skill import validate as validate_skill_dir, parse_frontmatter  # type: ignore
except ImportError:
    validate_skill_dir = None

    FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)

    def parse_frontmatter(text: str) -> dict:
        m = FRONTMATTER_RE.match(text)
        if not m:
            return {}
        out = {}
        for line in m.group(1).splitlines():
            km = re.match(r"^([A-Za-z][A-Za-z0-9_\-]+):\s*(.*)$", line)
            if km:
                out[km.group(1)] = km.group(2).strip().strip('"').strip("'")
        return out

# --- configuration -----------------------------------------------------------

DEFAULTS = {
    "allowlist_hosts": [
        "127.0.0.1", "localhost",
        "github.com", "raw.githubusercontent.com", "api.github.com",
        "registry.npmjs.org", "pypi.org", "files.pythonhosted.org",
        "api.anthropic.com", "api.openai.com", "openrouter.ai",
    ],
    "severity_overrides": {},
    "skip_globs": ["**/test/**", "**/tests/**", "**/fixtures/**", "**/__tests__/**"],
    "max_file_kb": 512,
    "quarantine_root": "active/quarantine",
    "token_dir": "active/.vet-approval",
    "token_ttl_seconds": 300,
}

MD_SUFFIXES = {".md", ".txt", ".mdx", ".markdown"}
SCRIPT_SUFFIXES = {".py", ".js", ".ts", ".mjs", ".cjs", ".sh", ".bash", ".zsh", ".rb"}
SKIP_SUFFIXES = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".pdf", ".zip", ".tar",
    ".gz", ".woff", ".woff2", ".ttf", ".otf", ".mp4", ".mov", ".lock", ".pyc",
}


def load_config(path: Path | None) -> dict:
    cfg = dict(DEFAULTS)
    candidates = [path] if path else [DEFAULT_CONFIG, WORKSPACE / "args" / "skill-vet.yaml"]
    for cand in candidates:
        if not cand or not cand.exists():
            continue
        loaded = _load_yaml(cand)
        if loaded:
            for key, value in loaded.items():
                if key in ("allowlist_hosts", "skip_globs") and isinstance(value, list):
                    cfg[key] = value
                elif key == "severity_overrides" and isinstance(value, dict):
                    cfg[key] = {**cfg["severity_overrides"], **value}
                elif key in DEFAULTS:
                    cfg[key] = value
    return cfg


def _load_yaml(path: Path) -> dict | None:
    try:
        import yaml  # type: ignore
        with open(path) as f:
            data = yaml.safe_load(f)
        return data if isinstance(data, dict) else None
    except ImportError:
        return _parse_simple_yaml(path.read_text(errors="replace"))
    except Exception:
        return None


def _parse_simple_yaml(text: str) -> dict:
    """Minimal fallback parser: top-level scalars, string lists, one-level maps."""
    out: dict = {}
    current_key = None
    current_map = None
    for raw in text.splitlines():
        if not raw.strip() or raw.strip().startswith("#"):
            continue
        if raw.startswith("  ") and current_key:
            item = raw.strip()
            if item.startswith("- "):
                out.setdefault(current_key, [])
                if isinstance(out[current_key], list):
                    out[current_key].append(item[2:].strip().strip('"').strip("'"))
            elif ":" in item and current_map is not None:
                k, _, v = item.partition(":")
                current_map[k.strip()] = v.strip().strip('"').strip("'")
            continue
        if ":" in raw:
            key, _, value = raw.partition(":")
            key, value = key.strip(), value.strip()
            if value == "":
                current_key = key
                current_map = {}
                out[key] = current_map if key == "severity_overrides" else out.get(key)
                if key != "severity_overrides":
                    current_map = None
            else:
                current_key = None
                current_map = None
                out[key] = int(value) if value.isdigit() else value.strip('"').strip("'")
    return out


# --- finding model -----------------------------------------------------------

@dataclass
class Finding:
    id: str
    severity: str  # BLOCK | REVIEW | INFO
    file: str
    line: int
    detail: str
    excerpt: str = ""


def _redact(s: str, keep: int = 60) -> str:
    s = s.strip().replace("\n", " ")
    return s[:keep] + ("..." if len(s) > keep else "")


class Scanner:
    def __init__(self, root: Path, config: dict):
        self.root = root
        self.cfg = config
        self.findings: list[Finding] = []
        # capability flags gathered across the whole repo (for cross-checks)
        self.repo_has_network = False
        self.repo_has_env_read = False
        self.script_capabilities: set[str] = set()  # {"network", "subprocess", "env"}

    # -- helpers --------------------------------------------------------------

    def add(self, fid: str, severity: str, file: Path, line: int, detail: str, excerpt: str = ""):
        severity = self.cfg["severity_overrides"].get(fid, severity)
        rel = file.relative_to(self.root).as_posix() if file != self.root else "."
        if self._in_skip_glob(rel):
            severity = {"BLOCK": "REVIEW", "REVIEW": "INFO"}.get(severity, severity)
        self.findings.append(Finding(fid, severity, rel, line, detail, _redact(excerpt)))

    def _in_skip_glob(self, rel: str) -> bool:
        from fnmatch import fnmatch
        return any(fnmatch(rel, g) for g in self.cfg["skip_globs"])

    def _host_allowed(self, host: str) -> bool:
        host = host.lower().split(":")[0]
        return any(host == a or host.endswith("." + a) for a in self.cfg["allowlist_hosts"])

    def _extract_hosts(self, text: str) -> list[str]:
        return re.findall(r"https?://([^/'\"\s)>\]]+)", text, re.IGNORECASE)

    def _iter_files(self):
        for p in sorted(self.root.rglob("*")):
            if not p.is_file():
                continue
            rel = p.relative_to(self.root).as_posix()
            if rel.startswith(".git/") or rel.startswith(".vet/"):
                continue
            if p.suffix.lower() in SKIP_SUFFIXES:
                continue
            if p.stat().st_size > self.cfg["max_file_kb"] * 1024:
                self.add("SC-SIZE-01", "INFO", p, 0, f"file over {self.cfg['max_file_kb']}KB, skipped")
                continue
            yield p

    def _read(self, p: Path) -> str | None:
        try:
            text = p.read_text(errors="replace")
        except OSError:
            return None
        if "\x00" in text[:1024]:
            return None
        return text

    # -- scan entry -----------------------------------------------------------

    def scan(self) -> str:
        files = list(self._iter_files())
        texts: dict[Path, str] = {}
        for p in files:
            text = self._read(p)
            if text is not None:
                texts[p] = text

        # Pass 1: scripts first, so frontmatter cross-checks know repo capabilities.
        for p, text in texts.items():
            if p.suffix.lower() in SCRIPT_SUFFIXES:
                self._scan_script(p, text)

        for p, text in texts.items():
            suffix = p.suffix.lower()
            if suffix in MD_SUFFIXES:
                self._scan_markdown(p, text)
            if p.name == "plugin.json" or p.name == "hooks.json":
                self._scan_plugin_json(p, text)
            if suffix == ".json" or p.name == ".mcp.json":
                self._scan_mcp_config(p, text)
            # secret patterns apply to every text file
            self._scan_secrets(p, text)

        # repo-wide escalation: sensitive-path reads become BLOCK when any
        # network capability exists anywhere in the repo
        if self.repo_has_network:
            for f in self.findings:
                if f.id == "SC-EXF-03" and f.severity == "REVIEW":
                    f.severity = "BLOCK"
                    f.detail += " (escalated: repo also makes network calls)"

        return self.verdict()

    def verdict(self) -> str:
        worst = max((SEVERITY_ORDER.get(f.severity, 0) for f in self.findings), default=0)
        return {0: "PASS", 1: "REVIEW", 2: "BLOCK"}[worst]

    # -- secrets (all files) ----------------------------------------------------

    def _scan_secrets(self, p: Path, text: str):
        for line_no, line in enumerate(text.splitlines(), 1):
            if len(line) > 4000:
                continue
            for name, regex in SECRET_PATTERNS.items():
                m = regex.search(line)
                if m and not any(m.group(0).startswith(ex) for ex in DOC_EXAMPLE_KEYS):
                    self.add("SC-SEC-01", "BLOCK", p, line_no,
                             f"embedded credential shape: {name}", m.group(0)[:12] + "...")

    # -- markdown surface -------------------------------------------------------

    INJECTION_PHRASES = re.compile(
        r"(ignore\s+(?:all\s+)?(?:previous|prior|above)\s+(?:instructions|prompts|rules)"
        r"|disregard\s+.{0,30}(?:instructions|rules|guidelines)"
        r"|do\s+not\s+(?:tell|inform|mention|reveal|disclose)(?:\s+this)?\s+to\s+the\s+user"
        r"|without\s+(?:telling|asking|informing|notifying)\s+the\s+user"
        r"|new\s+system\s+prompt"
        r"|you\s+must\s+(?:now|first|immediately)\s"
        r"|override\s+(?:your|the)\s+(?:instructions|system|rules))",
        re.IGNORECASE,
    )
    SECRET_NOUN_NEAR_VERB = re.compile(
        r"(?:\.env\b|api[\s_-]?keys?\b|credentials?\b|secrets?\b|tokens?\b|password)"
        r".{0,80}?"
        r"\b(?:read|cat|send|post|upload|email|curl|fetch|exfiltrat|transmit|forward)"
        r"|\b(?:read|cat|send|post|upload|email|curl|fetch|exfiltrat|transmit|forward)\w*"
        r".{0,80}?"
        r"(?:\.env\b|api[\s_-]?keys?\b|credentials?\b|secrets?\b|password)",
        re.IGNORECASE,
    )
    ZERO_WIDTH = re.compile(
        "[\u200b-\u200f\u202a-\u202e\u2060-\u2064\ufeff]"
    )
    HTML_COMMENT = re.compile(r"<!--(.*?)-->", re.DOTALL)
    BASE64_BLOB = re.compile(r"[A-Za-z0-9+/]{120,}={0,2}")
    REMOTE_LINK_WITH_QUERY = re.compile(r"!?\[[^\]]*\]\((https?://[^)]+\?[^)]+)\)")
    IMPERATIVE_TO_AGENT = re.compile(r"\b(?:you should|you must|claude:|assistant:)\b", re.IGNORECASE)

    def _scan_markdown(self, p: Path, text: str):
        if self.ZERO_WIDTH.search(text):
            line = next(i for i, ln in enumerate(text.splitlines(), 1) if self.ZERO_WIDTH.search(ln))
            self.add("MD-INJ-01", "BLOCK", p, line,
                     "zero-width or bidi unicode characters (hidden-text vector)")

        for line_no, line in enumerate(text.splitlines(), 1):
            m = self.INJECTION_PHRASES.search(line)
            if m:
                self.add("MD-INJ-02", "BLOCK", p, line_no, "prompt-injection phrase", m.group(0))
            m = self.SECRET_NOUN_NEAR_VERB.search(line)
            if m:
                self.add("MD-INJ-03", "BLOCK", p, line_no,
                         "secret material near exfil verb in prose", m.group(0))

        for m in self.HTML_COMMENT.finditer(text):
            body = m.group(1)
            line = text[:m.start()].count("\n") + 1
            if self.INJECTION_PHRASES.search(body) or self.SECRET_NOUN_NEAR_VERB.search(body):
                self.add("MD-INJ-04", "BLOCK", p, line, "injection content hidden in HTML comment", body)
            elif len(body) > 80 or self.IMPERATIVE_TO_AGENT.search(body):
                self.add("MD-INJ-05", "REVIEW", p, line, "long or agent-directed HTML comment", body)

        for m in self.BASE64_BLOB.finditer(text):
            line = text[:m.start()].count("\n") + 1
            blob = m.group(0)
            try:
                decoded = base64.b64decode(blob + "=" * (-len(blob) % 4)).decode("utf-8", "strict")
            except Exception:
                decoded = None
            if decoded and (self.INJECTION_PHRASES.search(decoded)
                            or self.SECRET_NOUN_NEAR_VERB.search(decoded)
                            or "http" in decoded.lower()):
                self.add("MD-INJ-06", "BLOCK", p, line,
                         "base64 blob decodes to injection content or URL", decoded)
            else:
                self.add("MD-INJ-06", "REVIEW", p, line, "opaque base64 blob in markdown", blob)

        for m in self.REMOTE_LINK_WITH_QUERY.finditer(text):
            url = m.group(1)
            hosts = self._extract_hosts(url)
            if hosts and not all(self._host_allowed(h) for h in hosts):
                line = text[:m.start()].count("\n") + 1
                self.add("MD-INJ-07", "REVIEW", p, line,
                         "remote link/image with query params to non-allowlisted host (beacon shape)", url)

        if p.name == "SKILL.md":
            self._scan_frontmatter(p, text)

    def _scan_frontmatter(self, p: Path, text: str):
        fm = parse_frontmatter(text)
        if not fm:
            return
        if "hooks" in fm:
            self.add("MD-FM-01", "REVIEW", p, 1,
                     "SKILL.md frontmatter declares hooks (runs commands on harness events)",
                     str(fm.get("hooks", "")))
        allowed = fm.get("allowed-tools", "")
        risky_caps = self.script_capabilities & {"network", "subprocess"}
        if allowed and risky_caps and "Bash" not in allowed:
            self.add("MD-FM-02", "REVIEW", p, 1,
                     f"allowed-tools omits Bash but bundled scripts use {sorted(risky_caps)}",
                     allowed)
        if validate_skill_dir is not None:
            result = validate_skill_dir(p.parent)
            for err in result.get("errors", []):
                self.add("MD-FM-04", "INFO", p, 1, f"workspace convention: {err}")

    # -- script surface -----------------------------------------------------------

    ENV_READ = re.compile(r"os\.environ|os\.getenv|process\.env|load_dotenv|dotenv|ENV\[")
    NETWORK_CALL = re.compile(
        r"requests\.(?:get|post|put|delete|request)|urllib\.request|http\.client"
        r"|httpx\.|aiohttp|\bfetch\s*\(|axios|XMLHttpRequest|net\.connect"
        r"|\bcurl\s|\bwget\s|Invoke-WebRequest|\biwr\s",
        re.IGNORECASE,
    )
    SENSITIVE_PATH_READ = re.compile(
        r"~/\.ssh|\.ssh/id_|~/\.aws|\.aws/credentials|~/\.config/gh|hosts\.yml"
        r"|security\s+find-(?:generic|internet)-password|/etc/passwd"
        r"|(?:\.\./)+\.env|(?:HOME|~)[\"'/]*[^\n]{0,40}\.env",
    )
    B64_DECODE = re.compile(r"base64\.b64decode|\batob\s*\(|Buffer\.from\([^)]*['\"]base64['\"]")
    EXEC_SINK = re.compile(r"\beval\s*\(|\bexec\s*\(|new\s+Function\s*\(|os\.system|subprocess|child_process")
    EXEC_REVIEW = re.compile(
        r"\beval\s*\(|\bexec\s*\(|new\s+Function\s*\(|os\.system\s*\(|os\.popen\s*\("
        r"|subprocess\.\w+\([^)]*shell\s*=\s*True|child_process|execSync|spawnSync",
    )
    DESERIALIZE = re.compile(r"pickle\.loads?\s*\(|marshal\.loads?\s*\(|yaml\.load\s*\((?![^)]*SafeLoader)")
    PIPE_TO_SHELL = re.compile(r"\b(?:curl|wget)\b[^|\n]*\|\s*(?:ba)?sh\b|\biwr\b[^|\n]*\|\s*iex\b", re.IGNORECASE)
    NETCAT = re.compile(r"\b(?:nc|netcat|ncat)\s+(?:-\w+\s+)*[\w.\-]+\s+\d+|/dev/tcp/", re.IGNORECASE)
    CONFIG_WRITE_TARGET = re.compile(
        r"(?:>>?|tee\s+(?:-a\s+)?|open\(\s*[\"'][^\"']*|write[\w_]*\(\s*[\"'][^\"']*|Path\(\s*[\"'][^\"']*)"
        r"[^\n\"']*(?:\.claude/|settings\.json|\.mcp\.json|\.zshrc|\.bashrc|\.bash_profile|\.profile\b|crontab|LaunchAgents)",
    )
    PATH_ESCAPE_WRITE = re.compile(
        r"(?:>>?\s*|tee\s+(?:-a\s+)?)(?:/(?!tmp\b)[\w.\-]+|~|\$HOME|\.\./)"
        r"|(?:open|write_text|writeFileSync|writeFile)\(\s*[\"'](?:/(?!tmp\b)|~|\.\./)",
    )
    DEP_INSTALL = re.compile(r"\bpip3?\s+install\b|\bnpm\s+install\b|\byarn\s+add\b|\buv\s+pip\s+install\b")

    def _scan_script(self, p: Path, text: str):
        lines = text.splitlines()
        has_env = bool(self.ENV_READ.search(text))
        has_net = bool(self.NETWORK_CALL.search(text))
        hosts = self._extract_hosts(text)
        bad_hosts = [h for h in hosts if not self._host_allowed(h)]

        if has_env:
            self.repo_has_env_read = True
            self.script_capabilities.add("env")
        if has_net:
            self.repo_has_network = True
            self.script_capabilities.add("network")
        if self.EXEC_SINK.search(text):
            self.script_capabilities.add("subprocess")

        def first_line(regex: re.Pattern) -> tuple[int, str]:
            for i, ln in enumerate(lines, 1):
                m = regex.search(ln)
                if m:
                    return i, m.group(0)
            return 0, ""

        if has_env and has_net:
            line, excerpt = first_line(self.NETWORK_CALL)
            if bad_hosts:
                self.add("SC-EXF-01", "BLOCK", p, line,
                         f"env read + network call to non-allowlisted host(s) {bad_hosts[:3]} in same file",
                         excerpt)
            else:
                self.add("SC-EXF-02", "REVIEW", p, line,
                         "env read + network call in same file (hosts allowlisted or dynamic)", excerpt)
        elif has_net and bad_hosts:
            line, excerpt = first_line(self.NETWORK_CALL)
            self.add("SC-NET-01", "REVIEW", p, line,
                     f"network call to non-allowlisted host(s) {bad_hosts[:3]}", excerpt)

        m_line, m_ex = first_line(self.SENSITIVE_PATH_READ)
        if m_line:
            self.add("SC-EXF-03", "REVIEW", p, m_line,
                     "reads sensitive path (ssh/aws/keychain/external .env)", m_ex)

        if self.B64_DECODE.search(text) and self.EXEC_SINK.search(text):
            line, excerpt = first_line(self.B64_DECODE)
            self.add("SC-OBF-01", "BLOCK", p, line,
                     "base64 decode coexists with exec/eval/subprocess (obfuscated payload shape)", excerpt)
        elif self.EXEC_SINK.search(text):
            for i, ln in enumerate(lines, 1):
                if len(ln) > 200 and _shannon_entropy(ln) > 4.5:
                    self.add("SC-OBF-02", "REVIEW", p, i,
                             "high-entropy long string in file that also uses exec/eval", ln)
                    break

        m_line, m_ex = first_line(self.EXEC_REVIEW)
        if m_line:
            self.add("SC-EXE-01", "REVIEW", p, m_line, "dynamic execution / shell capability", m_ex)

        m_line, m_ex = first_line(self.DESERIALIZE)
        if m_line:
            self.add("SC-EXE-02", "REVIEW", p, m_line, "unsafe deserialization (pickle/marshal/yaml.load)", m_ex)

        m_line, m_ex = first_line(self.PIPE_TO_SHELL)
        if m_line:
            self.add("SC-SH-01", "BLOCK", p, m_line, "pipe-to-shell (curl|sh)", m_ex)

        if p.suffix in {".sh", ".bash", ".zsh"}:
            m_line, m_ex = first_line(self.NETCAT)
            if m_line:
                self.add("SC-SH-02", "BLOCK", p, m_line, "netcat / raw tcp socket in shell script", m_ex)

        m_line, m_ex = first_line(self.CONFIG_WRITE_TARGET)
        if m_line:
            self.add("SC-FS-01", "BLOCK", p, m_line,
                     "writes to agent config / shell rc / crontab (persistence vector)", m_ex)
        else:
            m_line, m_ex = first_line(self.PATH_ESCAPE_WRITE)
            if m_line:
                self.add("SC-FS-02", "REVIEW", p, m_line, "writes outside repo directory", m_ex)

        m_line, m_ex = first_line(self.DEP_INSTALL)
        if m_line:
            self.add("SC-DEP-01", "REVIEW", p, m_line, "runtime dependency install inside script", m_ex)

    # -- plugin.json surface ------------------------------------------------------

    def _scan_plugin_json(self, p: Path, text: str):
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            self.add("PL-HK-01", "REVIEW", p, 1, "plugin manifest is not valid JSON")
            return
        hooks = data.get("hooks", {})
        if not hooks:
            return
        for event, entries in hooks.items() if isinstance(hooks, dict) else []:
            for entry in entries if isinstance(entries, list) else []:
                for hook in entry.get("hooks", []) if isinstance(entry, dict) else []:
                    cmd = hook.get("command", "") if isinstance(hook, dict) else str(hook)
                    self.add("PL-HK-01", "REVIEW", p, 1,
                             f"plugin hook on {event}: runs a command on harness events", cmd)
                    if (self.PIPE_TO_SHELL.search(cmd) or self.NETCAT.search(cmd)
                            or self.B64_DECODE.search(cmd) or "base64" in cmd
                            or any(not self._host_allowed(h) for h in self._extract_hosts(cmd))):
                        self.add("PL-HK-02", "BLOCK", p, 1,
                                 f"plugin hook command on {event} contains network/shell/encode primitives", cmd)
                    self._scan_hook_script_refs(p, cmd)
        if "mcpServers" in data:
            self._check_mcp_servers(p, data["mcpServers"])

    def _scan_hook_script_refs(self, manifest: Path, cmd: str):
        # resolve ${CLAUDE_PLUGIN_ROOT}/relative refs against the repo root
        for ref in re.findall(r"\$\{CLAUDE_PLUGIN_ROOT\}/([\w./\-]+)", cmd):
            target = self.root / ref
            if not target.exists():
                self.add("PL-HK-03", "REVIEW", manifest, 1,
                         f"hook references missing file: {ref}")

    # -- MCP surface ----------------------------------------------------------------

    UNPINNED_NPX = re.compile(r"\bnpx\s+(?:-y\s+|--yes\s+)?(?!.*@\d)[@\w/.\-]+")
    UNPINNED_UVX = re.compile(r"\buvx\s+(?![\w\-]+==)[\w\-]+")

    def _scan_mcp_config(self, p: Path, text: str):
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return
        servers = data.get("mcpServers") if isinstance(data, dict) else None
        if isinstance(servers, dict):
            self._check_mcp_servers(p, servers)

    def _check_mcp_servers(self, p: Path, servers: dict):
        for name, spec in servers.items():
            if not isinstance(spec, dict):
                continue
            command = spec.get("command", "")
            args = spec.get("args", [])
            full = " ".join([command] + [str(a) for a in args])
            if command in ("curl", "bash", "sh", "wget") or full.strip().startswith("http"):
                self.add("MC-PIN-02", "BLOCK", p, 1,
                         f"MCP server '{name}' executes via shell/URL, not a registry package", full)
            elif (("npx" in full and not re.search(r"@\d[\w.\-]*", full))
                    or ("uvx" in full and not re.search(r"==[\d.]+", full))):
                self.add("MC-PIN-01", "REVIEW", p, 1,
                         f"MCP server '{name}' uses unpinned npx/uvx (auto-runs latest from registry)", full)
            env = spec.get("env", {})
            if isinstance(env, dict):
                secretish = [k for k in env if re.search(r"KEY|TOKEN|SECRET|PASSWORD", k, re.IGNORECASE)]
                if secretish:
                    self.add("MC-ENV-01", "REVIEW", p, 1,
                             f"MCP server '{name}' forwards secret env vars {secretish[:5]}")
            url = spec.get("url", "")
            if url:
                hosts = self._extract_hosts(url)
                if hosts and not all(self._host_allowed(h) for h in hosts):
                    self.add("MC-NET-01", "REVIEW", p, 1,
                             f"remote MCP server '{name}' on non-allowlisted host", url)


def _shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    freq: dict[str, int] = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in freq.values())


# --- tree hashing + git metadata ------------------------------------------------

def tree_sha256(root: Path) -> str:
    """sha256 over sorted (relpath, content) pairs, skipping .git/ and .vet/."""
    h = hashlib.sha256()
    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(root).as_posix()
        if rel.startswith(".git/") or rel.startswith(".vet/"):
            continue
        h.update(rel.encode())
        h.update(b"\x00")
        try:
            h.update(p.read_bytes())
        except OSError:
            continue
        h.update(b"\x00")
    return h.hexdigest()


def git_commit_sha(root: Path) -> str:
    try:
        out = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"],
                             capture_output=True, text=True, timeout=10)
        return out.stdout.strip() if out.returncode == 0 else ""
    except (OSError, subprocess.TimeoutExpired):
        return ""


# --- subcommands ------------------------------------------------------------------

def cmd_scan(args) -> int:
    root = Path(args.quarantine_dir).resolve()
    if not root.is_dir():
        print(f"[skill-vet] not a directory: {root}", file=sys.stderr)
        return 2
    cfg = load_config(Path(args.config) if args.config else None)
    scanner = Scanner(root, cfg)
    verdict = scanner.scan()

    report = {
        "slug": root.name,
        "commit_sha": git_commit_sha(root),
        "tree_sha256": tree_sha256(root),
        "verdict": verdict,
        "findings": [asdict(f) for f in scanner.findings],
        "scanned_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
    }
    vet_dir = root / ".vet"
    vet_dir.mkdir(exist_ok=True)
    (vet_dir / "findings.json").write_text(json.dumps(report, indent=2))

    if args.json:
        print(json.dumps(report, indent=2))
    else:
        _print_scan_summary(report)
    return EXIT_FOR_VERDICT[verdict]


def _print_scan_summary(report: dict):
    print(f"[skill-vet] {report['slug']}  verdict: {report['verdict']}")
    print(f"  tree sha256: {report['tree_sha256'][:16]}...  commit: {report['commit_sha'][:8] or 'n/a'}")
    counts = {"BLOCK": 0, "REVIEW": 0, "INFO": 0}
    for f in report["findings"]:
        counts[f["severity"]] = counts.get(f["severity"], 0) + 1
    print(f"  findings: {counts['BLOCK']} BLOCK / {counts['REVIEW']} REVIEW / {counts['INFO']} INFO")
    for f in sorted(report["findings"], key=lambda x: -SEVERITY_ORDER.get(x["severity"], 0)):
        if f["severity"] == "INFO":
            continue
        print(f"  [{f['severity']}] {f['id']} {f['file']}:{f['line']} — {f['detail']}")
        if f["excerpt"]:
            print(f"           {f['excerpt']}")


def _token_path(cfg: dict, slug: str) -> Path:
    return WORKSPACE / cfg["token_dir"] / f"{slug}.json"


def cmd_approve(args) -> int:
    cfg = load_config(Path(args.config) if args.config else None)
    quarantine = WORKSPACE / cfg["quarantine_root"] / args.slug
    findings_file = quarantine / ".vet" / "findings.json"
    if not findings_file.exists():
        print(f"[skill-vet] no findings.json for '{args.slug}' — run scan first.", file=sys.stderr)
        return 2
    report = json.loads(findings_file.read_text())

    l1 = report["verdict"]
    llm = (args.llm_verdict or "PASS").upper()
    if llm not in SEVERITY_ORDER:
        print(f"[skill-vet] invalid --llm-verdict '{args.llm_verdict}'", file=sys.stderr)
        return 2
    # escalate-only merge: the LLM reviewer can worsen, never improve, the verdict
    final = max(l1, llm, key=lambda v: SEVERITY_ORDER[v])

    if final == "BLOCK":
        print(f"[skill-vet] DENIED: final verdict is BLOCK (L1={l1}, LLM={llm}). No token written.")
        return 2
    if final == "REVIEW" and not args.approved_by_human:
        print(f"[skill-vet] DENIED: verdict REVIEW requires --approved-by-human "
              f"(only after the operator typed 'INSTALL {args.slug}').")
        return 1

    current_sha = tree_sha256(quarantine)
    if current_sha != report["tree_sha256"]:
        print("[skill-vet] DENIED: quarantine tree changed since scan. Re-run scan.", file=sys.stderr)
        return 2

    token_path = _token_path(cfg, args.slug)
    token_path.parent.mkdir(parents=True, exist_ok=True)
    token_path.write_text(json.dumps({
        "slug": args.slug,
        "quarantine_path": str(quarantine),
        "tree_sha256": current_sha,
        "verdict": "approved_review" if final == "REVIEW" else "PASS",
        "approved_by_human": bool(args.approved_by_human),
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
    }, indent=2))
    print(f"[skill-vet] approval token written: {token_path} (TTL {cfg['token_ttl_seconds']}s)")
    return 0


def cmd_install(args) -> int:
    cfg = load_config(Path(args.config) if args.config else None)
    quarantine = WORKSPACE / cfg["quarantine_root"] / args.slug
    token_path = _token_path(cfg, args.slug)
    if not token_path.exists():
        print(f"[skill-vet] DENIED: no approval token for '{args.slug}'. Run approve first.", file=sys.stderr)
        return 2
    token = json.loads(token_path.read_text())
    age = time.time() - token_path.stat().st_mtime
    if age > cfg["token_ttl_seconds"]:
        print(f"[skill-vet] DENIED: token expired ({int(age)}s old, TTL {cfg['token_ttl_seconds']}s).",
              file=sys.stderr)
        return 2
    if token.get("verdict") not in ("PASS", "approved_review"):
        print(f"[skill-vet] DENIED: token verdict '{token.get('verdict')}' not installable.", file=sys.stderr)
        return 2

    current_sha = tree_sha256(quarantine)
    if current_sha != token["tree_sha256"]:
        print("[skill-vet] DENIED: quarantine tree was modified after approval "
              "(scan-then-tamper). Re-run scan.", file=sys.stderr)
        return 2

    dest = Path(args.dest).resolve()
    if dest.exists():
        print(f"[skill-vet] DENIED: destination already exists: {dest}", file=sys.stderr)
        return 2
    shutil.copytree(quarantine, dest, ignore=shutil.ignore_patterns(".git", ".vet"))
    token_path.unlink()  # single-use
    print(f"[skill-vet] installed {args.slug} -> {dest}")

    if validate_skill_dir is not None and (dest / "SKILL.md").exists():
        result = validate_skill_dir(dest)
        for err in result.get("errors", []):
            print(f"  convention error (fix before shipping): {err}")
        for warn in result.get("warnings", []):
            print(f"  convention warning: {warn}")
    return 0


def cmd_hash(args) -> int:
    print(tree_sha256(Path(args.dir).resolve()))
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Quarantine scanner + install gate for third-party repos.")
    sub = p.add_subparsers(dest="command", required=True)

    s = sub.add_parser("scan", help="scan a quarantined repo, write findings.json, exit 0/1/2")
    s.add_argument("quarantine_dir")
    s.add_argument("--json", action="store_true")
    s.add_argument("--config")
    s.set_defaults(func=cmd_scan)

    a = sub.add_parser("approve", help="write a single-use install token (escalate-only merge)")
    a.add_argument("slug")
    a.add_argument("--llm-verdict", default="PASS")
    a.add_argument("--approved-by-human", action="store_true")
    a.add_argument("--config")
    a.set_defaults(func=cmd_approve)

    i = sub.add_parser("install", help="verify token + tree hash, copy quarantine -> dest")
    i.add_argument("slug")
    i.add_argument("--dest", required=True)
    i.add_argument("--config")
    i.set_defaults(func=cmd_install)

    h = sub.add_parser("hash", help="print tree sha256 of a directory")
    h.add_argument("dir")
    h.set_defaults(func=cmd_hash)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
