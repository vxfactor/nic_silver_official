#!/usr/bin/env python3
"""
vet_install_gate.py — standalone PreToolUse hook for the skill-vet gate.

Combines two checks in one file (dispatched on tool_name) so a single hook
covers both install paths:

  1. Bash commands that move third-party code into protected install targets
     (.claude/skills/, .claude/plugins/, .mcp.json) are blocked unless the
     source passed /skill-vet and a fresh approval token exists.
  2. Write/Edit calls on .mcp.json that introduce an unpinned npx/uvx MCP
     server are blocked unless a fresh approval token exists.

Exit 0 = allow. Exit 2 = block (reason printed to stdout).

Wire it in .claude/settings.json (see settings-snippet.json):

  "PreToolUse": [
    {"matcher": "Bash",                 "hooks": [{"type": "command", "command": "python3 .claude/hooks/vet_install_gate.py"}]},
    {"matcher": "Write|Edit|MultiEdit", "hooks": [{"type": "command", "command": "python3 .claude/hooks/vet_install_gate.py"}]}
  ]

This hook is a coarse early-deny net. The precise enforcement (tree sha256
binding, verdict check, single-use token) lives in skill_vet.py install.
"""

from __future__ import annotations

import json
import re
import sys
import time
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[2]
QUARANTINE_MARKER = "active/quarantine/"
TOKEN_DIR = WORKSPACE / "active" / ".vet-approval"
TOKEN_TTL_SECONDS = 300

PROTECTED_INSTALL_TARGETS = (
    ".claude/skills/",
    ".claude/plugins/",
    ".agents/skills/",
    ".mcp.json",
)
INSTALL_VERBS_RE = re.compile(r"\b(?:cp|mv|rsync|ditto|tar|unzip)\b")
EXTERNAL_SOURCE_RE = re.compile(r"(?:^|\s)(?:/tmp/|/private/tmp/|~/Downloads/|\$HOME/Downloads/)")


def _fresh_token(slug: str) -> bool:
    token = TOKEN_DIR / f"{slug}.json"
    try:
        if not token.is_file():
            return False
        if (time.time() - token.stat().st_mtime) > TOKEN_TTL_SECONDS:
            return False
        return json.loads(token.read_text()).get("verdict") in ("PASS", "approved_review")
    except (OSError, ValueError):
        return False


def _any_fresh_token() -> bool:
    try:
        if not TOKEN_DIR.exists():
            return False
        now = time.time()
        return any(
            p.is_file() and (now - p.stat().st_mtime) <= TOKEN_TTL_SECONDS
            for p in TOKEN_DIR.iterdir()
        )
    except OSError:
        return False


# --- Bash path ----------------------------------------------------------------

def check_bash(command: str) -> str | None:
    """Return a block reason, or None to allow."""
    # skill_vet.py is the vetting tool itself; exempt a single unchained invocation.
    if re.match(r"^\s*(?:python3?\s+)?\S*skill_vet\.py\s", command) and not re.search(r"[;&|]", command):
        return None

    if not any(t in command for t in PROTECTED_INSTALL_TARGETS):
        return None

    if "git clone" in command:
        return (
            "BLOCKED: git clone directly into a protected install target. "
            "Third-party repos go through quarantine first: "
            "git clone --depth 1 <url> active/quarantine/<slug>/ then run /skill-vet."
        )

    if QUARANTINE_MARKER in command:
        m = re.search(r"active/quarantine/([\w.\-]+)", command)
        slug = m.group(1) if m else ""
        if slug and _fresh_token(slug):
            return None
        return (
            f"BLOCKED: installing '{slug or 'unknown'}' from quarantine without a fresh "
            f"skill-vet approval token. Run /skill-vet (scan -> verdict -> approve -> "
            f"install). Prefer skill_vet.py install, which also verifies the tree hash."
        )

    if INSTALL_VERBS_RE.search(command) and EXTERNAL_SOURCE_RE.search(command):
        return (
            "BLOCKED: copying external files (/tmp, ~/Downloads) into a protected "
            "install target. Move the repo to active/quarantine/<slug>/ and run "
            "/skill-vet first."
        )
    return None


# --- Write/Edit path ------------------------------------------------------------

def _has_unpinned_server(content: str) -> bool:
    try:
        data = json.loads(content)
        servers = data.get("mcpServers", {}) if isinstance(data, dict) else {}
        for spec in servers.values():
            if not isinstance(spec, dict):
                continue
            full = " ".join([spec.get("command", "")] + [str(a) for a in spec.get("args", [])])
            if "npx" in full and not re.search(r"@\d[\w.\-]*", full):
                return True
            if "uvx" in full and not re.search(r"==\d", full):
                return True
        return False
    except (ValueError, AttributeError):
        if "npx" in content and not re.search(r"@\d[\w.\-]*", content):
            return True
        if "uvx" in content and not re.search(r"==\d", content):
            return True
        return False


def check_edit(file_path: str, content: str) -> str | None:
    if not file_path.endswith(".mcp.json"):
        return None
    if not _has_unpinned_server(content):
        return None
    if _any_fresh_token():
        return None
    return (
        "BLOCKED: this edit adds an unpinned npx/uvx MCP server to an .mcp.json. "
        "Unpinned servers auto-run the latest registry version (supply-chain risk). "
        "Either pin an exact version (pkg@x.y.z / pkg==x.y.z) or vet the server "
        "through /skill-vet first."
    )


def _extract_edit_content(tool_name: str, tool_input: dict) -> tuple[str, str]:
    file_path = tool_input.get("file_path") or ""
    if tool_name == "Write":
        return file_path, tool_input.get("content") or ""
    if tool_name == "Edit":
        return file_path, tool_input.get("new_string") or ""
    if tool_name == "MultiEdit":
        chunks = [e.get("new_string") or "" for e in tool_input.get("edits") or []]
        return file_path, "\n".join(chunks)
    return file_path, ""


def main() -> None:
    try:
        data = json.loads(sys.stdin.read() or "{}")
        tool_name = data.get("tool_name") or ""
        tool_input = data.get("tool_input") or {}

        reason = None
        if tool_name == "Bash" or (not tool_name and "command" in tool_input):
            reason = check_bash(tool_input.get("command", ""))
        elif tool_name in ("Write", "Edit", "MultiEdit"):
            file_path, content = _extract_edit_content(tool_name, tool_input)
            reason = check_edit(file_path, content)

        if reason:
            print(reason)
            sys.exit(2)
        sys.exit(0)
    except SystemExit:
        raise
    except Exception:
        sys.exit(0)  # a broken hook must never brick the harness


if __name__ == "__main__":
    main()
