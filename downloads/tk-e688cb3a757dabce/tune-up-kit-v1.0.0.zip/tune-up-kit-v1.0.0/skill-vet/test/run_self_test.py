#!/usr/bin/env python3
"""Self-test for a skill-vet install. Run from the repo/workspace root:

    python3 test/run_self_test.py            # inside the template repo
    python3 .claude/skill-vet-test/run_self_test.py   # if you copied it into a project

Scans the four bundled fixture repos and checks the exit codes, then probes the
install gate hook with simulated payloads. Everything local, nothing sent anywhere.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

# Resolve layout: template repo (skills/... at root) or installed project (.claude/skills/...)
CANDIDATE_SCANNERS = [
    ROOT / "skills" / "skill-vet" / "scripts" / "skill_vet.py",
    ROOT / ".claude" / "skills" / "skill-vet" / "scripts" / "skill_vet.py",
]
SCANNER = next((p for p in CANDIDATE_SCANNERS if p.exists()), None)
CANDIDATE_HOOKS = [
    ROOT / "hooks" / "vet_install_gate.py",
    ROOT / ".claude" / "hooks" / "vet_install_gate.py",
]
HOOK = next((p for p in CANDIDATE_HOOKS if p.exists()), None)
FIXTURES = HERE.parent / "fixtures"

EXPECTED = {
    "clean-skill": 0,      # PASS
    "injection-md": 2,     # BLOCK — prompt injection in SKILL.md
    "exfil-script": 2,     # BLOCK — env read + network call to unknown host
    "hooked-plugin": 1,    # REVIEW — plugin declares a SessionStart hook
}

failures = []


def check(label: str, ok: bool) -> None:
    print(("PASS " if ok else "FAIL ") + label)
    if not ok:
        failures.append(label)


def main() -> int:
    if SCANNER is None:
        print("FAIL could not locate skill_vet.py")
        return 1

    for slug, want in EXPECTED.items():
        fixture = FIXTURES / slug
        if not fixture.is_dir():
            check(f"fixture present: {slug}", False)
            continue
        proc = subprocess.run([sys.executable, str(SCANNER), "scan", str(fixture)],
                              capture_output=True, text=True)
        check(f"scan {slug} -> exit {want}", proc.returncode == want)

    if HOOK is None:
        print("SKIP hook tests (vet_install_gate.py not found)")
    else:
        def hook_exit(payload: dict) -> int:
            proc = subprocess.run([sys.executable, str(HOOK)], input=json.dumps(payload),
                                  capture_output=True, text=True)
            return proc.returncode

        skills_dir = ".claude/" + "skills/"
        quar = "active/" + "quarantine/"
        check("hook blocks quarantine->skills without token",
              hook_exit({"tool_name": "Bash",
                         "tool_input": {"command": f"cp -r {quar}x {skills_dir}x"}}) == 2)
        check("hook allows unrelated command",
              hook_exit({"tool_name": "Bash", "tool_input": {"command": "git status"}}) == 0)
        unpinned = json.dumps({"mcpServers": {"t": {"command": "npx", "args": ["-y", "@x/y"]}}})
        check("hook blocks unpinned npx in .mcp.json",
              hook_exit({"tool_name": "Write",
                         "tool_input": {"file_path": "/proj/.mcp.json", "content": unpinned}}) == 2)

    print()
    if failures:
        print(f"{len(failures)} FAILURES")
        return 1
    print("ALL SELF-TESTS PASSED — the gate is working.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
