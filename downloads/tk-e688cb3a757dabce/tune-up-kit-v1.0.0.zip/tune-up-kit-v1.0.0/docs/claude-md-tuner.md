# CLAUDE.md Tuner

Your CLAUDE.md file loads into the model's context on every session. Every line costs tokens before the first prompt runs. A bloated file wastes money, slows the model down, and buries the rules that actually matter under ones that are just reference padding.

This doc covers how to get your instruction file lean without losing any teeth.

Our memory layer dropped about 72% in always-loaded size after one pass of this process. The rules enforced did not change.

---

## The core idea

CLAUDE.md is an index, not a library.

It should tell the model where to find things, not contain the things themselves. Deep docs, long rule explanations, and verbose examples belong in separate files that load on demand. CLAUDE.md points at them.

Target: under 300 lines. If you are over that, something is embedded that should be referenced.

---

## Before and after sketch

**Before (bloated):**

```markdown
## Voice

Write in plain English. Sentences should average 20 words or fewer. Use concrete nouns.
Avoid jargon and corporate filler words (your rules file should list the exact banned list).
Avoid em-dashes and ASCII double-dash used as a dash. Use commas, colons, or parentheses.
Do not use throat-clearing phrases like "Before we dive in". Just say the thing.
Run the 5-second test: if the reader leaves after 5 seconds, do they know one concrete thing?
Run the 14-year-old test: would a smart 14-year-old follow without Googling?
```

**After (lean index):**

```markdown
## Voice

Plain English. Short sentences. Concrete nouns. No banned words (see content-voice.md).
No em-dashes. No "before we dive in" throat-clearing. 5-second test and 14-year-old test
on every artifact before shipping.

Full rules: `.claude/rules/content-voice.md` (always-loaded).
```

The rule is still enforced. The file that enforces it is still the same. CLAUDE.md just stopped being a copy of it.

---

## Memory index rules

If you maintain a memory index file (a per-project log of past decisions and shipped work), apply these rules:

- One line per entry. 200 characters maximum.
- Link to the detail file. Do not embed the detail.
- For versioned project chains (v1, v2, v3 of the same thing), keep only the latest state and any still-open flags.
- Evict entries where the work is complete and there is no ongoing hook. They still live in topic files.
- Keep entries for: standing rules with teeth, open tasks with your next action, API gotchas that will bite again.

Example of a good index entry:

```
- [Payment scan v2 (2024-01-15)](project_payment_scan.md): auto-stages onboarding on receipt. OPEN: test key.
```

Example of a bad index entry:

```
- [Payment scan v2 (2024-01-15)](project_payment_scan.md): The payment scan skill was rebuilt in phase 2
  to automatically trigger the onboarding sequence when a Stripe payment is detected. It reads from the
  payments table, matches by email, and calls the onboarding webhook. We switched from polling to
  event-based detection after the polling approach missed payments that arrived between scan windows.
  OPEN: swap test key for production key before go-live.
```

All that prose in the second version will be loaded into every session forever. Put it in the topic file.

---

## 20-minute trim checklist

Work through these in order. Check each off when done.

**[ ] 1. Measure your baseline.**
Count the lines in CLAUDE.md. Estimate tokens (rough: 4 characters per token). Write the numbers down. You need a baseline to know if the trim worked.

**[ ] 2. Find embedded rule text.**
Search for any section that repeats content already in a rules file. If CLAUDE.md has a paragraph about voice or security, and you also have `rules/content-voice.md` and `rules/security.md`, the paragraph is redundant. Replace it with a one-line pointer.

**[ ] 3. Find embedded reference material.**
Tool names, API field names, config values, detailed how-to instructions. These belong in a referenced file, not in CLAUDE.md. Replace with a pointer.

**[ ] 4. Compress the Capabilities section.**
Capabilities should be one line per item with a pointer to the detail doc or skill. If a capability entry runs longer than one line, it belongs in a context file.

**[ ] 5. Compress the memory index.**
Apply the memory index rules above. For each entry: is the work complete with no ongoing hook? Evict it. Is the entry more than one line? Compress it and move the detail to a topic file.

**[ ] 6. Collapse versioned project chains.**
If you have v1, v2, v3 entries for the same project, keep only the terminal state. If there are open flags from an earlier version, keep one line pointing at them.

**[ ] 7. Convert subsection headers to bold inline labels.**
H3 headers (`### Output rules`) take a full line and add visual noise. `**Output rules:**` on the same line as its content saves lines and reads just as clearly.

**[ ] 8. Trim intro and outro text.**
Opening paragraphs that explain the purpose of the file are rarely read after the first session. Cut them to one sentence or remove them entirely.

**[ ] 9. Check the What Not To Do section.**
Long parenthetical explanations of why a rule exists belong in a context file or in a comment in the relevant hook or script. Keep only the actionable line.

**[ ] 10. Re-count and verify.**
Run your line count again. Are you under 300? Good. Now do a teeth check: for every rule or gate that matters, confirm it is still reachable within one hop (CLAUDE.md pointer to the file, or the file itself). Nothing enforced only by the removed prose should have disappeared.

---

## Routing table pattern

Instead of repeating information about multiple systems inline, use a table that routes to the right file:

```markdown
## Key files

| Path | Purpose |
|------|---------|
| `.claude/rules/` | Always-loaded rules |
| `.claude/context/` | Deep reference, load on demand |
| `.claude/skills/` | Skill definitions |
| `second-brain/wiki/hot.md` | Current operational state |
| `args/preferences.yaml` | Runtime behavior settings |
```

Any time a doc tries to describe what each rule file does inline, replace it with this pattern and point to a README in the rules directory.

---

## What to never trim

These things must stay in CLAUDE.md regardless of line count:

- Paths to files that contain rules with real teeth (hooks, gates, linters).
- The model routing summary (which model runs which tier of task).
- The output structure for where generated artifacts go.
- Any "never do this" entry that a hook or script does NOT already enforce. Prose-only rules that matter must stay visible.
- The pointer to the memory index.

If you are unsure whether something is safe to move to a referenced file, keep it in CLAUDE.md and add a pointer to the longer version. Moving things to files only works if the model will actually follow the pointer when it matters.
