# Context Fork and Skill Chaining

Multi-step skills bleed tokens fast. Every tool call, every web scrape, every sub-step response lands in the main context window and stays there. By step 10, you have paid for every previous step's full output whether you needed it or not.

The three-layer pattern below keeps those costs under control. Our measured result: 85% token cut on one daily pipeline that processes external data across several steps.

Use all three layers together on heavy, frequent skills. Use two of three on lighter ones. Use none when the skill is a single shot or runs less than weekly.

---

## When to use this pattern

Apply all three layers when ALL of these are true:

- The skill has three or more distinct phases (labelled Phase, Step, or numbered sections).
- The skill runs at least weekly, or produces large intermediate outputs (scraped pages, API dumps, transcripts).
- A wrong intermediate result would cascade into downstream steps.

Skip the pattern when:

- The skill runs once per session (audits, status checks, index builders).
- The skill requires a human decision mid-run (approval gates, send confirmations). Forking breaks those flows.
- The skill is conversational or interactive.
- The whole skill runs in under two minutes on light input.

---

## Layer 1: Context fork

Add `context: fork` to the skill's frontmatter. The skill runs inside an isolated sub-agent with its own context window. When the fork exits, all tool responses from that window are discarded. Only the final summary returns to the main conversation.

```yaml
---
name: my-skill
context: fork
tier: auto
domain: research
---
```

This is a Claude Code native primitive. If you run the same skill under a different harness (Codex, a script runner), document a sequential fallback path in the SKILL.md so the skill still works. Label the two paths clearly:

```markdown
## Run command

### Claude Code (preferred)
The orchestrator sub-skill spawns and writes results to tmp/.

### Sequential fallback
Run each script in order from a top-level shell script.
```

---

## Layer 2: File handoff

Each step writes only the data the next step needs, not its full output.

Directory convention:

```
active/<skill-name>/tmp/<run-id>/
  step1-output.json   # written by step 1, read by step 2
  step2-output.json   # written by step 2, read by step 3
  ...
```

Use a short timestamp or random ID for `<run-id>` so parallel runs do not collide.

Rules for handoff files:

- Keep them small. A 200-byte JSON with three fields is better than a 4 KB raw API response.
- Include only what the next step will actually read. Strip everything else before writing.
- If a step produces files larger than 10 MB, delete them inside the skill before moving on.
- Files older than 14 days in `active/*/tmp/` can be swept automatically. Do not store anything you cannot afford to lose there.

This layer works under any harness because it is just shell and file I/O.

---

## Layer 3: Bang command substitution

When a step needs to read the previous step's output, use a bang substitution instead of a tool call:

```
!`cat active/<skill-name>/tmp/${RUN_ID}/step1-output.json`
```

The shell command runs when the skill loads. The output is substituted into the prompt text at zero additional token cost. The AI never sees the read happen as a tool call, so it does not pay for it.

Use this wherever a step needs to reference a previous step's file. Do NOT use your AI client's file-read tool for handoff files. That tool call costs tokens and defeats the purpose of Layer 2.

Order matters: the file must exist before the bang runs. If step 2's bang tries to read step 1's output before step 1 has written it, you will get an error. Make sure steps run in the right order.

---

## Failures to avoid

- **Forking a two-minute skill.** The sub-agent startup overhead is not worth it for light work. Fork only when there are at least five thousand tokens of working memory or three distinct phases.
- **Bloated handoff files.** If your step 1 output is 8 KB, you have not trimmed it enough. The handoff file should contain only what step 2 will read.
- **Using the AI's Read tool instead of a bang.** That is a tool call. It costs tokens. Use the bang.
- **Bang commands that reference files not yet written.** Substitution runs at load time. Order your steps so each file exists before the next step's bang fires.
- **No sequential fallback documented.** If you use `context: fork`, document the fallback path. Otherwise the skill is broken for anyone not running Claude Code.

---

## Worked example skeleton

This is a two-step research-and-score skill you can copy and adapt.

```yaml
---
name: research-and-score
context: fork
tier: auto
domain: research
---

# Research and Score

Runs in an isolated fork. Writes intermediate results to tmp/. Returns only the final score.

## Step 1: Gather data

Use your web search tool to find the three most relevant sources for the topic below.

Topic: ${TOPIC}

Write a JSON file to `active/research-and-score/tmp/${RUN_ID}/sources.json`.
Format:
{
  "sources": [
    { "url": "...", "title": "...", "key_point": "..." }
  ]
}

Keep the key_point under 80 characters.

## Step 2: Score

You are given the sources from step 1:

<sources>
!`cat active/research-and-score/tmp/${RUN_ID}/sources.json`
</sources>

Score the quality of the evidence on a scale of 1-10 based on:
- Source credibility
- Relevance to the topic
- Recency (prefer sources from the last 12 months)

Write `active/research-and-score/tmp/${RUN_ID}/score.json`:
{
  "score": <1-10>,
  "reason": "<one sentence>"
}

## Output

Return only the score and reason to the main conversation.
```

---

## Pre-ship check

Before declaring a chained skill done, run these from your project root:

```bash
# Fork declared in frontmatter
grep -c "^context: fork" .claude/skills/<skill-name>/SKILL.md
# Expected: 1

# Bang commands present
grep -cE '!`[^`]+`' .claude/skills/<skill-name>/SKILL.md
# Expected: >= 1 if Layer 3 applies

# Handoff directory referenced
grep -cE 'tmp/\$\{RUN_ID\}' .claude/skills/<skill-name>/SKILL.md
# Expected: >= 1

# Sequential fallback documented
grep -iE 'sequential|fallback' .claude/skills/<skill-name>/SKILL.md
# Expected: >= 1 if context: fork is used
```

All four pass? The skill is chained correctly.
