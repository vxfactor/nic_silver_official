# Lazy Loading: Skills, MCP Servers, and CLI Scripts

Not everything needs to be ready on session start. Loading tools and definitions up front costs tokens before the first prompt runs. The question is: which things should always be ready, and which should load only when needed?

This doc covers three options: MCP servers, skills, and CLI scripts. It explains the token cost of each and when to reach for each one.

---

## The problem with MCP servers at scale

When Claude Code starts a session, it asks every connected MCP server to list its tools. The server responds with the full schema for every tool it provides: name, description, parameters, types, defaults. All of that lands in the context window before you have typed a single message.

A small MCP server might add a few hundred tokens. A large one can add tens of thousands. If you have several large MCP servers connected, you may be paying 20,000 or more tokens just to see what tools are available, every session, whether you use those tools or not.

You cannot defer this. MCP tool definitions are announced at connection time. There is no "load this tool only when I ask for it" option in the current protocol.

---

## How skills stay cheaper

A skill is a Markdown file. When Claude Code lists available skills, it reads only the skill name and a one-line description from the frontmatter. The full body of the skill, which may include dozens of steps, tool instructions, and examples, does not load until you invoke the skill.

This means 120 skills in your skills directory costs roughly the same as 120 short strings at session start. You pay for the skill body only when you run it.

This is the core trade-off: MCP servers trade token cost for tight integration and real-time tool access. Skills trade that integration for cheap startup and easy customization.

---

## When to use each option

**Use an MCP server when:**
- The tool needs real-time data or live API access that a script cannot replicate.
- The tool needs to run mid-conversation without a separate trigger (browsing, searching, reading a live database).
- The tool is used in most sessions, so the always-on token cost is justified.

**Use a skill when:**
- The workflow is multi-step and can be described as a prompt sequence.
- You run it on demand, not in every session.
- You want to customize the behavior without touching integration code.
- The workflow involves chaining several tools together in a predictable order.

**Use a CLI script when:**
- The task is mechanical and does not need AI reasoning (file moves, data format conversions, bulk API calls with known inputs).
- You want deterministic output, not a best-effort generation.
- The task is called from inside a skill as a sub-step.
- Speed and repeatability matter more than flexibility.

A common pattern is: skill orchestrates, CLI script executes. The skill handles the reasoning and sequencing. The CLI script does the mechanical work at the end.

---

## How to audit what loads at session start

Run this from your project root to see how many tools your MCP servers are advertising:

```bash
# List connected MCP servers from your config
cat .mcp.json | python3 -c "import sys,json; d=json.load(sys.stdin); [print(k) for k in d.get('mcpServers',{}).keys()]"
```

Then for each server, check what it declares. If a server is connected but you use it less than once a week, consider disconnecting it from the project config and calling it via CLI when you need it.

Check your skills directory for stale skills that run rarely:

```bash
# Skills not invoked in the last 14 days (requires skill execution logs or modification dates as proxy)
find .claude/skills -name "SKILL.md" -mtime +14 | head -20
```

Skills with old modification dates that you rarely use are fine to leave in place: they add almost nothing to session startup. Rarely used MCP servers cost you on every session.

---

## Summary table

| Option | Session startup cost | Best for |
|--------|---------------------|----------|
| MCP server | High (full tool schemas) | Frequent, real-time tool access |
| Skill | Very low (name + one line) | On-demand workflows, customizable sequences |
| CLI script | Zero | Mechanical tasks, deterministic execution, called from skills |

Start with skills and CLI scripts. Add an MCP server when real-time integration is genuinely needed and you will use it most sessions.
