# Cross-Agent Compatibility

How to run the same AI workspace under Claude Code today and Codex (or any
future agent runtime) tomorrow, without rebuilding anything.

---

## 1. The problem: one vendor, one point of failure

If your entire AI workflow runs through a single provider, their outage is your
outage. Their price hike lands on you with no alternative. Their plan limit
stops work that day.

This is not theoretical. AI providers hit rate limits, change pricing tiers, and
deprecate features on short notice. The practical answer is not to predict which
provider will cause trouble -- it is to make switching (or running a backup)
something you can do in minutes, not days.

The pattern here solves that for the instruction layer: the files that tell your
AI how to behave.

---

## 2. The pattern: two instruction files, one tagging convention

Claude Code reads a file called `CLAUDE.md` at the workspace root. Codex CLI
reads a file called `AGENTS.md`. Other agents that follow the AGENTS.md
convention also read that file.

The pattern is simple:

- `CLAUDE.md` holds everything: rules that apply to Claude specifically, plus
  rules that should apply to any runtime.
- `AGENTS.md` holds only the shared rules -- the subset that works across
  harnesses.
- When you write a rule that belongs in both files, you tag it `[universal]` in
  `CLAUDE.md`, then copy the same bullet into `AGENTS.md`.

That tag is your single source of truth. The drift checker (see section 5) reads
both files and reports any `[universal]` bullet that appears in `CLAUDE.md` but
not in `AGENTS.md`.

### What goes in each file

| What | CLAUDE.md | AGENTS.md |
|------|-----------|-----------|
| Voice and copy rules | Yes, tagged [universal] | Yes |
| Output format conventions | Yes, tagged [universal] | Yes |
| Security rules | Yes, tagged [universal] | Yes |
| Workspace layout description | Yes, tagged [universal] | Yes |
| Skill library location | Yes, tagged [universal] | Yes |
| Claude-specific hooks | Yes, NOT [universal] | No |
| Subagent definitions | Yes, NOT [universal] | No |
| Plan mode settings | Yes, NOT [universal] | No |
| Slash command idioms | Yes, NOT [universal] | No |

The rule of thumb: if Codex or another agent would follow the instruction
correctly, tag it [universal] and mirror it. If it references a mechanism that
only Claude Code supports, leave it in `CLAUDE.md` only.

---

## 3. What does not port

Be clear-eyed about the things that cannot cross runtimes. Trying to force them
produces confusion, not portability.

**Hooks.** Claude Code runs lifecycle hooks (pre-tool-use, post-tool-use) defined
in `settings.json`. These fire automatically and cannot be blocked by reasoning.
Codex has no equivalent hook system. Rules that depend on hooks must be enforced
by other means in Codex -- usually by adding a manual check step to your
workflow, or by baking the check into a script the agent calls explicitly.

**Subagent definitions.** Claude Code can spawn specialized subagents from
`.claude/agents/` definition files. Codex runs as a single agent. Workflows that
fan out to subagents need to be restructured as sequential steps when running
under Codex.

**Plan mode.** Claude Code has a dedicated plan mode that enforces a clarify-then-
execute discipline. Codex does not. The same outcome (clarifying questions before
building) can be approximated with a rule in `AGENTS.md`, but it is not
enforced mechanically.

**Slash commands.** Skills invoked as `/skill-name` in Claude Code map to `.agents/
skills/` for Codex, but the invocation syntax differs. Codex typically needs the
skill name written out as a phrase rather than a slash command.

None of this prevents meaningful portability. Voice, security, output format,
skill logic, and workspace conventions travel cleanly. The mechanical guardrails
need human attention when switching runtimes.

---

## 4. The handoff file pattern

When you stop work mid-task and want to continue in a different runtime (or just
a new session), write a short handoff note before you stop.

The handoff note lives in `active/handoff/` and contains:

- The exact last thing you asked the agent to do (verbatim).
- Where the task landed: decisions made, files changed, open questions.
- The next concrete step.

When the new session starts, it reads the most recent file in `active/handoff/`
(any file that does not end in `.consumed.md`), summarizes it back to you, and
asks whether to continue or start fresh. After acting on it, it renames the file
with a `.consumed.md` suffix so the same handoff is not re-surfaced.

File naming convention: `YYYY-MM-DD-HHMM-<slug>.md`, for example
`2026-06-12-1430-leadgen-followup.md`.

Retention: 30 days. Handoff notes are not disposable intermediates -- you might
come back to a stalled task weeks later.

For `AGENTS.md` to pick up handoffs automatically, include a section in it that
tells the agent to scan `active/handoff/` on session start. The relevant section
heading is typically "Resuming work started in another session".

---

## 5. The drift checker

`lib/check_agents_sync.py` is a small stdlib-only script that confirms your two
instruction files are in sync.

What it checks:

1. Both `CLAUDE.md` and `AGENTS.md` exist at the workspace root.
2. Both files contain their expected section headers (configurable at the top of
   the script).
3. Every `[universal]`-tagged bullet in `CLAUDE.md` appears in `AGENTS.md` (matched
   on the first 60 characters of the bullet body).
4. `CLAUDE.md` is under a soft size cap (default 35 KB). Beyond that size, the file
   starts to load slowly and becomes harder to maintain -- a signal to move detail
   into a separate log file.

Running it:

```bash
# Basic check -- prints clean or lists issues:
python3 lib/check_agents_sync.py

# Verbose -- prints every check result, not just failures:
python3 lib/check_agents_sync.py --verbose
```

What the output means:

- `CLAUDE.md <-> AGENTS.md sync: clean` -- all [universal] bullets are mirrored.
  Byte sizes and bullet count are shown for reference.
- `AGENTS.md: missing [universal] mirror for: 'Research stack: EXA -> Firecr...'`
  -- you added or changed a [universal] rule in `CLAUDE.md` and forgot to update
  `AGENTS.md`. Copy the bullet across and re-run.
- `CLAUDE.md: missing expected section header '## Capabilities'` -- the file
  structure changed in a way that breaks the checker. Fix the header or update the
  `CLAUDE_REQUIRED_HEADERS` list in the script.
- Exit code 2 -- a file is missing entirely. Create it and run again.

Run this weekly as a maintenance step, or wire it into a pre-commit hook if your
workspace uses git commits as a save point.

---

## 6. Setup checklist (15 minutes)

Work through this in order. Each step builds on the previous one.

**Step 1 (2 min): confirm your instruction files exist.**
Check that `CLAUDE.md` is at your workspace root and that it has a `## Capabilities`
section. If `AGENTS.md` does not exist, create it with at minimum a `## Identity`
section and a `## Capabilities` section.

**Step 2 (5 min): tag your shared rules.**
Read through `CLAUDE.md`. For each rule that any AI runtime should follow (voice,
security, output format, workspace layout), add `[universal]` to the start of that
bullet. Then copy each tagged bullet into the relevant section of `AGENTS.md`.

**Step 3 (2 min): mark the Claude-only items.**
Rules that reference hooks, subagents, plan mode, or slash commands stay in
`CLAUDE.md` only. You do not need to tag them -- absence of `[universal]` is the
signal.

**Step 4 (2 min): run the checker.**
```bash
python3 lib/check_agents_sync.py --verbose
```
Fix any reported gaps. The checker exits 0 when everything is clean.

**Step 5 (2 min): create the handoff folder.**
```bash
mkdir -p active/handoff
```
Add the following to the top of `AGENTS.md` (after the Identity section):

> On session start, scan `active/handoff/` for the most recent `.md` file that
> does NOT end in `.consumed.md`. If one exists, read it, summarize it to the
> user in one short paragraph, and ask whether to continue or start fresh.
> After acting on it, rename the file with a `.consumed.md` suffix.

**Step 6 (2 min): schedule the weekly check.**
Add a calendar reminder or a cron entry to run `python3 lib/check_agents_sync.py`
once a week. Drift is slow but it compounds -- a rule added in Claude Code in
January is missing from Codex by March.

---

## Ongoing maintenance

The only ongoing work is: when you add or change a rule in `CLAUDE.md`, ask
yourself "does this apply to all runtimes?" If yes, tag it `[universal]` and copy
it to `AGENTS.md`. The weekly checker catches anything you miss.

Keep `AGENTS.md` lean. It is a distillation, not a copy. Detail that is Claude-
specific, or that belongs in a separate reference file, stays out of it.
