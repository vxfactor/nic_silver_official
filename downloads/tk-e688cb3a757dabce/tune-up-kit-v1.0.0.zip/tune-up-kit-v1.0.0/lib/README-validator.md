# Skill Validator -- README

## What it does

Every skill in a Claude Code workspace introduces itself through a SKILL.md file.
The AI reads that file to know the skill exists, what it does, and how to call it.
If the frontmatter is missing, malformed, or has a broken name, the AI cannot
reliably pick up the skill -- even though the file is right there on disk.

The validator pair in this folder catches those problems as you write, not later
when you notice the AI ignoring a skill you just built.

- **validate_skill.py** -- the core validator. Call it from the command line or
  import it from another script. Returns a result dict with errors and warnings
  for each skill it checks.

- **skill_md_validate.py** (in hooks/) -- a Claude Code PostToolUse hook. It
  fires automatically every time a SKILL.md is written or edited, runs the
  validator on that file, and prints any problems to stderr. Non-blocking: the
  write always goes through; this is a nudge, not a gate.

Together they mean every skill introduces itself properly, or the AI gets told
about the problem right away.


## Why it matters

A skill with no `name` key silently vanishes from the AI's awareness. A `name`
that is not kebab-case may be ignored by strict loaders. A `description` over
1024 chars hits the Anthropic hard cap and gets truncated. None of these produce
an obvious error -- the skill just does not work the way you expect.

The hook catches all of these on the first write so you fix them while the
context is fresh.


## Install

1. Copy `lib/validate_skill.py` into your workspace at `.claude/lib/validate_skill.py`.

2. Copy `hooks/skill_md_validate.py` into your workspace at
   `.claude/hooks/skill_md_validate.py`.

3. Register the hook in `.claude/settings.json`. Add it under `hooks.PostToolUse`
   alongside any existing hooks you already have:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Write|Edit|MultiEdit",
        "hooks": [
          {
            "type": "command",
            "command": "python3 .claude/hooks/skill_md_validate.py"
          }
        ]
      }
    ]
  }
}
```

   If you already have a PostToolUse array, add only the object inside `"hooks"`
   to your existing matcher, or add a new matcher entry -- whichever fits your
   current structure.

4. Restart Claude Code so it picks up the new hook.


## How to run manually

Validate one skill:

```bash
python3 .claude/lib/validate_skill.py .claude/skills/my-skill
```

Validate every skill in the workspace:

```bash
python3 .claude/lib/validate_skill.py --all
```

Get JSON output (useful for scripting):

```bash
python3 .claude/lib/validate_skill.py --all --json
```

Exit with code 1 if any skill has an error (useful in CI):

```bash
python3 .claude/lib/validate_skill.py --all --fail-on-error
```


## What the validator checks

### Errors (fix before shipping)

| Check | Why |
|---|---|
| SKILL.md missing or no frontmatter | AI cannot read the skill at all |
| `name` missing, not kebab-case, or over 64 chars | Loaders reject or mangle bad names |
| `description` missing | AI has nothing to match on when deciding to call the skill |
| `description` contains `<` or `>` | Angle brackets trip some loaders; move placeholders to `argument-hint` |
| `description` over 1024 chars | Anthropic hard cap; truncation breaks the skill description |
| Unknown frontmatter key | Almost always a typo; catches drift from the allowed key set |

### Warnings (soft nudges)

| Check | Why |
|---|---|
| `description` over 250 chars | Some runtimes apply a soft progressive-disclosure cap |
| SKILL.md body over 500 lines | Long files are hard to scan; move reference material to `references/` |
| Em-dash in description | Some parsers choke on Unicode dashes; use a comma or parentheses |
| Neither `tier` nor `model` declared | The AI defaults to the most expensive model; declaring one routes it cheaper |


## Optional frontmatter keys

The validator recognises (but does not require) these keys. If your workspace
adopts any of them, your skills validate clean without needing to modify this tool.

```
business-tier   domain          tier            model
effort          argument-hint   allowed-tools   disallowedTools
disable-model-invocation        user-invocable  portability
context         agent           hooks           skills
mcpServers      maxTurns        permissionMode  isolation
memory          license         metadata        compatibility
homepage        repository      author          version
```

Any key outside this list is flagged as an error (likely a typo).


## Minimum valid SKILL.md

```markdown
---
name: my-skill
description: Does X when you ask for Y.
---

Body goes here.
```

That is enough to validate clean. Everything else is optional.
