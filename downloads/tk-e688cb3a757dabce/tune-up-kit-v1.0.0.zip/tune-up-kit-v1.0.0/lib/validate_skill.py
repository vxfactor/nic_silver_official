#!/usr/bin/env python3
"""
validate_skill.py -- generic SKILL.md validator for Claude Code workspaces.

Use this anywhere a skill is created or checked:
  - a PostToolUse hook that fires on every SKILL.md write  (see hooks/skill_md_validate.py)
  - a manual scan: python3 lib/validate_skill.py --all

ERRORS (the skill will not be picked up reliably by the AI):
  - SKILL.md missing or no YAML frontmatter
  - name missing, not kebab-case, or over 64 chars
  - description missing, contains < or >, or over 1024 chars (Anthropic hard cap)
  - unknown frontmatter key (likely a typo)

WARNINGS (soft nudges -- never block the write):
  - description over 250 chars (Codex progressive-disclosure soft cap)
  - SKILL.md body over 500 lines (put reference material in a references/ subfolder)
  - em-dash in description (use a comma or parentheses instead)
  - neither tier nor model declared (the AI will default to the most expensive model)

Usage:
    python3 lib/validate_skill.py <skill_dir>               # one skill
    python3 lib/validate_skill.py --all                     # every skill under .claude/skills/
    python3 lib/validate_skill.py --all --json
    python3 lib/validate_skill.py <dir> --fail-on-error     # exit 1 on any error
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
SKILLS_DIR = REPO / ".claude" / "skills"

FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)

# Every key this validator recognises as intentional.
# Keys not on this list trigger an error so typos are caught early.
# Optional workspace conventions (business-tier, domain, portability, etc.) are
# included here so workspaces that adopt them validate clean, but they are NOT
# required -- only name and description are required.
ALLOWED_KEYS = {
    # core (required)
    "name", "description",
    # optional workspace conventions
    "business-tier", "domain", "tier", "model", "effort",
    "argument-hint", "allowed-tools", "disallowedTools",
    "disable-model-invocation", "user-invocable", "portability",
    "context", "agent", "hooks", "skills", "mcpServers",
    "maxTurns", "permissionMode", "isolation", "memory",
    # Anthropic spec + ecosystem passthrough (vendored skills carry these)
    "license", "metadata", "compatibility",
    "homepage", "repository", "author", "version",
}

# Only name and description are required. Every other key is optional so
# buyers are not forced into any particular workspace convention.
REQUIRED = {"name", "description"}

DESC_HARD_CAP = 1024   # Anthropic spec
DESC_SOFT_CAP = 250    # Codex progressive-disclosure cap
BODY_LINE_CAP = 500    # keep SKILL.md concise; move reference material to references/


def parse_frontmatter(text: str) -> dict[str, str]:
    """Parse YAML frontmatter without yaml.safe_load.

    SKILL.md descriptions routinely contain colons, pipes, and brackets that
    break a strict YAML parser, so we do a line-by-line parse instead.
    """
    m = FRONTMATTER_RE.match(text)
    if not m:
        return {}
    block = m.group(1)
    out: dict[str, str] = {}
    lines = block.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        key_match = re.match(r"^([A-Za-z][A-Za-z0-9_\-]+):\s*(.*)$", line)
        if not key_match:
            i += 1
            continue
        key, value = key_match.group(1), key_match.group(2).strip()
        if value in {"", ">", ">-", "|", "|-"}:
            parts: list[str] = []
            j = i + 1
            while j < len(lines) and (lines[j].startswith(" ") or lines[j].startswith("\t")):
                parts.append(lines[j].strip())
                j += 1
            value = " ".join(parts)
            i = j
        else:
            i += 1
        out[key] = value.strip().strip('"').strip("'")
    return out


def validate(skill_dir: Path) -> dict:
    """Return {slug, ok, errors, warnings} for one skill directory."""
    slug = skill_dir.name
    errors: list[str] = []
    warnings: list[str] = []

    skill_md = skill_dir / "SKILL.md"
    if not skill_md.exists():
        return {"slug": slug, "ok": False, "errors": ["SKILL.md not found"], "warnings": []}

    text = skill_md.read_text(errors="replace")
    if not text.lstrip().startswith("---"):
        return {"slug": slug, "ok": False, "errors": ["no YAML frontmatter"], "warnings": []}

    fm = parse_frontmatter(text)
    if not fm:
        return {"slug": slug, "ok": False, "errors": ["frontmatter did not parse"], "warnings": []}

    # Unknown keys -- catch typos early
    for key in fm:
        if key not in ALLOWED_KEYS:
            errors.append(f"unknown frontmatter key '{key}' (not in allowed set -- typo?)")

    # Required fields
    for key in REQUIRED:
        if not fm.get(key):
            errors.append(f"missing required '{key}'")

    # name format
    name = fm.get("name", "")
    if name:
        if not re.match(r"^[a-z0-9-]+$", name):
            errors.append(f"name '{name}' must be kebab-case (lowercase letters, digits, hyphens only)")
        elif name.startswith("-") or name.endswith("-") or "--" in name:
            errors.append(f"name '{name}' cannot start or end with a hyphen, or contain '--'")
        if len(name) > 64:
            errors.append(f"name too long ({len(name)} chars, max 64)")

    # description checks
    desc = fm.get("description", "")
    if desc:
        # Angle brackets trip some loaders (Codex strict mode, XML-ish parsers).
        # Move <placeholder>-style text to argument-hint instead.
        if "<" in desc or ">" in desc:
            warnings.append("description contains angle brackets -- move <placeholder> text to argument-hint")
        if len(desc) > DESC_HARD_CAP:
            errors.append(f"description {len(desc)} chars over hard cap {DESC_HARD_CAP}")
        elif len(desc) > DESC_SOFT_CAP:
            warnings.append(f"description {len(desc)} chars over soft cap {DESC_SOFT_CAP}")
        if "—" in desc:
            warnings.append("description contains an em-dash -- use a comma or parentheses instead")

    # Model routing -- soft nudge only (warning, not error)
    if not (fm.get("tier") or fm.get("model")):
        warnings.append(
            "skill runs on the default model, usually the most expensive one; "
            "declare model: or tier: to route it cheaper"
        )

    # Body length -- soft nudge
    body_lines = text.count("\n")
    if body_lines > BODY_LINE_CAP:
        warnings.append(
            f"SKILL.md is {body_lines} lines (over {BODY_LINE_CAP}); "
            "move reference material to a references/ subfolder to keep it scannable"
        )

    return {"slug": slug, "ok": not errors, "errors": errors, "warnings": warnings}


def scan_all() -> list[dict]:
    out = []
    for d in sorted(SKILLS_DIR.iterdir()):
        if d.is_dir() and (d / "SKILL.md").exists():
            out.append(validate(d))
    return out


def _print_one(r: dict) -> None:
    status = "OK" if r["ok"] else "FAIL"
    print(f"[{status}] {r['slug']}")
    for e in r["errors"]:
        print(f"  error:   {e}")
    for w in r["warnings"]:
        print(f"  warning: {w}")


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Validate SKILL.md files against Claude Code conventions.")
    p.add_argument("skill_dir", nargs="?", help="path to one skill directory")
    p.add_argument("--all", action="store_true", help="validate every skill under .claude/skills/")
    p.add_argument("--json", action="store_true", help="emit JSON")
    p.add_argument("--fail-on-error", action="store_true", help="exit 1 if any skill has an error")
    args = p.parse_args(argv)

    if args.all:
        results = scan_all()
    elif args.skill_dir:
        results = [validate(Path(args.skill_dir))]
    else:
        p.error("pass a skill directory or --all")
        return 2

    if args.json:
        print(json.dumps(results, indent=2))
    else:
        failed = [r for r in results if not r["ok"]]
        warned = [r for r in results if r["ok"] and r["warnings"]]
        if len(results) > 1:
            print(f"{len(results)} skills  {len(failed)} with errors  {len(warned)} warn-only\n")
        for r in results:
            if not r["ok"] or r["warnings"] or len(results) == 1:
                _print_one(r)

    if args.fail_on_error and any(not r["ok"] for r in results):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
