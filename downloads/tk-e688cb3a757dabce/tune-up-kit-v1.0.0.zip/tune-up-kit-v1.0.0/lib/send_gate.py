"""
Outbound action approval gate.

Contract:

  - Your send/post/pay function refuses to execute unless
    consume_approval(action_kind, target, payload, workspace_root) returns True.
  - Tokens are written ONLY by request_approval(...), which requires the
    human to type "APPROVE <ACTION_KIND>" verbatim after seeing the full
    rendered payload.
  - Tokens live at <workspace>/.claude/.action-approval/<sha256> with a
    5-minute TTL and are single-use (deleted on consumption).
  - The sha256 hash binds (action_kind, target, payload). Editing any of
    those three fields after approval invalidates the token by design.
  - A fabricated token file with the wrong sha cannot pass consume_approval
    because the call site recomputes the hash independently.

Supported action kinds (examples): "EMAIL", "POST", "PAYMENT", "WEBHOOK".
The kind string becomes the phrase the human must type, so keep it short
and uppercase, e.g. APPROVE EMAIL, APPROVE POST, APPROVE PAYMENT.

Stdlib only. No third-party dependencies.
"""

from __future__ import annotations

import hashlib
import os
import sys
import time
from pathlib import Path

TTL_SECONDS = 300  # 5 minutes
_APPROVAL_SUBDIR = ".claude/.action-approval"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _approval_dir(workspace_root: str | Path) -> Path:
    return Path(workspace_root) / _APPROVAL_SUBDIR


def _compute_hash(action_kind: str, target: str, payload: str) -> str:
    """sha256 over the three fields that define an approved action."""
    h = hashlib.sha256()
    h.update(action_kind.strip().upper().encode("utf-8"))
    h.update(b"\x00")
    h.update((target or "").strip().encode("utf-8"))
    h.update(b"\x00")
    h.update((payload or "").encode("utf-8"))
    return h.hexdigest()


def _token_path(action_kind: str, target: str, payload: str, workspace_root: str | Path) -> Path:
    return _approval_dir(workspace_root) / _compute_hash(action_kind, target, payload)


def _confirm_phrase(action_kind: str) -> str:
    return f"APPROVE {action_kind.strip().upper()}"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def request_approval(
    action_kind: str,
    target: str,
    payload: str,
    workspace_root: str | Path,
    *,
    label: str = "",
) -> bool:
    """Show the full action details and require "APPROVE <ACTION_KIND>" verbatim.

    Writes a sha256-bound single-use token on confirmation. Returns True iff
    approved (and token was written). Returns False on any other input, or if
    stdin is not a TTY (non-interactive context).

    Args:
        action_kind: Short uppercase string identifying the action type,
                     e.g. "EMAIL", "POST", "PAYMENT". This becomes part of
                     the required confirmation phrase.
        target:      The destination, e.g. an email address, social handle,
                     or API endpoint. Shown to the human and bound to the token.
        payload:     The full content being authorized, e.g. the email body,
                     post text, or payment JSON. Shown in full and bound to
                     the token.
        workspace_root: Absolute path to the workspace root. Tokens are stored
                        under <workspace_root>/.claude/.action-approval/.
        label:       Optional human-readable label shown in the header, e.g.
                     "welcome email to new signup". Does not affect the hash.
    """
    if not sys.stdin.isatty():
        print(
            f"[send_gate] ERROR: interactive approval required but stdin is not a TTY.\n"
            f"  Run this command in an interactive terminal, or bypass the gate for\n"
            f"  test sends by routing to a safe sandbox address.",
            file=sys.stderr,
        )
        return False

    phrase = _confirm_phrase(action_kind)
    bar = "=" * 72
    header_label = f"  ({label})" if label else ""
    digest_preview = _compute_hash(action_kind, target, payload)[:16]

    print(f"\n{bar}", file=sys.stderr)
    print(f"  ACTION APPROVAL REQUIRED{header_label}", file=sys.stderr)
    print(bar, file=sys.stderr)
    print(f"  Kind:    {action_kind.upper()}", file=sys.stderr)
    print(f"  Target:  {target}", file=sys.stderr)
    print(f"  Hash:    {digest_preview}...", file=sys.stderr)
    print(f"  TTL:     {TTL_SECONDS}s after approval, single-use", file=sys.stderr)
    print("\n  --- PAYLOAD ---", file=sys.stderr)
    for line in (payload or "").splitlines() or [""]:
        print(f"  {line}", file=sys.stderr)
    print("  --- END PAYLOAD ---\n", file=sys.stderr)
    print(
        f"  Type exactly  {phrase}  to authorize this action.\n"
        "  Anything else aborts. The token is bound to (kind, target, payload);\n"
        "  any edit to those fields after approval invalidates the token.",
        file=sys.stderr,
    )
    try:
        answer = input("  > ")
    except (EOFError, KeyboardInterrupt):
        print("\n[send_gate] aborted.", file=sys.stderr)
        return False

    if answer.strip() != phrase:
        print(
            f"\n  Confirmation phrase did not match. No token written. Action blocked.",
            file=sys.stderr,
        )
        return False

    # Write token
    adir = _approval_dir(workspace_root)
    adir.mkdir(parents=True, exist_ok=True)
    token = _token_path(action_kind, target, payload, workspace_root)
    token.write_text(
        f"kind={action_kind.upper()}\n"
        f"target={target}\n"
        f"created_at={int(time.time())}\n"
    )
    try:
        os.chmod(token, 0o600)
    except OSError:
        pass

    print(
        f"\n  Approval token written ({token.name[:16]}...). "
        f"Single-use, expires in {TTL_SECONDS}s.",
        file=sys.stderr,
    )
    return True


def consume_approval(
    action_kind: str,
    target: str,
    payload: str,
    workspace_root: str | Path,
) -> bool:
    """Single-use consumption. Returns True iff a fresh token existed and was deleted.

    Call this inside your send/post/pay function immediately before executing
    the outbound action. The token is deleted on the first successful call;
    a second call with the same arguments returns False.

    Args:
        action_kind: Must match exactly what was passed to request_approval.
        target:      Must match exactly what was passed to request_approval.
        payload:     Must match exactly what was passed to request_approval.
        workspace_root: Absolute path to the workspace root.

    Returns:
        True  -- token was fresh and has now been consumed. Proceed with send.
        False -- token missing, stale, or already consumed. Block the send.
    """
    token = _token_path(action_kind, target, payload, workspace_root)
    if not token.exists():
        return False
    try:
        age = time.time() - token.stat().st_mtime
    except OSError:
        return False
    if age > TTL_SECONDS:
        try:
            token.unlink()
        except OSError:
            pass
        return False
    try:
        token.unlink()
    except OSError:
        return False
    return True


def any_fresh_token(workspace_root: str | Path) -> bool:
    """Coarse check for hook layers. Returns True if any token is fresh.

    Does NOT consume any token. Use this in a PreToolUse hook to gate on
    whether any approval is currently in flight. The exact-hash check in
    consume_approval is the real gate; this is a fast early filter only.
    """
    adir = _approval_dir(workspace_root)
    if not adir.exists():
        return False
    now = time.time()
    for p in adir.iterdir():
        try:
            if p.is_file() and (now - p.stat().st_mtime) <= TTL_SECONDS:
                return True
        except OSError:
            continue
    return False


def block_message(action_kind: str, target: str, workspace_root: str | Path) -> str:
    """Human-readable message to print when an action is blocked by the gate."""
    adir = _approval_dir(workspace_root)
    phrase = _confirm_phrase(action_kind)
    return (
        f"\n=== ACTION BLOCKED: {action_kind.upper()} ===\n"
        f"Target:  {target!r}\n"
        f"\nNo fresh approval token found at {adir}/<sha256>.\n"
        f"\nTo authorize: call request_approval(...) in an interactive terminal.\n"
        f"You will see the full payload and must type {phrase!r} verbatim.\n"
        "===========================================\n"
    )


# ---------------------------------------------------------------------------
# Demo (run this to verify the gate works in 30 seconds)
# ---------------------------------------------------------------------------

def _demo() -> None:
    """Gate a fake email so you can see the full approval flow.

    Run:  python send_gate.py
    Then type:  APPROVE EMAIL
    """
    import tempfile

    workspace = Path(tempfile.mkdtemp(prefix="send_gate_demo_"))
    print(f"[demo] using temp workspace: {workspace}", file=sys.stderr)

    kind = "EMAIL"
    target = "john.smith@example.com"
    payload = (
        "Subject: Your account is ready\n"
        "\n"
        "Hi John,\n"
        "\n"
        "Your workspace has been set up. Log in at https://example.com/login\n"
        "\n"
        "Let me know if you have any questions.\n"
    )

    print("\n[demo] Step 1: request approval", file=sys.stderr)
    approved = request_approval(kind, target, payload, workspace, label="demo welcome email")

    if not approved:
        print("[demo] Approval declined or aborted. Nothing sent.", file=sys.stderr)
        return

    print("\n[demo] Step 2: consume approval (simulating the send function)", file=sys.stderr)
    ok = consume_approval(kind, target, payload, workspace)
    if ok:
        print("[demo] consume_approval returned True. In a real send function,", file=sys.stderr)
        print("       the email would now be sent to john.smith@example.com.", file=sys.stderr)
    else:
        print("[demo] consume_approval returned False (token expired or already used).", file=sys.stderr)

    print("\n[demo] Step 3: try to consume again (must return False)", file=sys.stderr)
    second = consume_approval(kind, target, payload, workspace)
    print(f"[demo] second consume returned: {second} (expected False)", file=sys.stderr)

    # Clean up temp dir
    import shutil
    shutil.rmtree(workspace, ignore_errors=True)
    print(f"[demo] temp workspace removed.", file=sys.stderr)


if __name__ == "__main__":
    _demo()
