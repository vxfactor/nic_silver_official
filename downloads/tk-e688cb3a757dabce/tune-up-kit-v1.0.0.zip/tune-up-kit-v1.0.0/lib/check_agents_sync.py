#!/usr/bin/env python3
"""Check that CLAUDE.md and AGENTS.md stay in sync on shared (universal) rules.

The cross-agent compatibility pattern uses two instruction files side by side:

  CLAUDE.md   -- the Claude Code instruction file. Contains everything: Claude-specific
                 settings (hooks, subagent definitions, plan mode), plus shared rules
                 that also apply to other AI runtimes.

  AGENTS.md   -- the runtime-neutral overlay. Read by Codex CLI and other agents that
                 respect the AGENTS.md convention. Contains ONLY the rules that apply
                 across runtimes, not anything Claude-specific.

The tagging convention: when a rule belongs in both files, mark it [universal] in
CLAUDE.md. This script checks that every [universal]-tagged bullet in CLAUDE.md also
appears somewhere in AGENTS.md (matched by a 60-character fingerprint). If a bullet
drifts out of AGENTS.md -- because someone edited one file and forgot the other --
this script reports it.

Run it weekly, or add it as a pre-commit check.

Exit code 0 = clean.
Exit code 1 = drift found (details printed to stderr).
Exit code 2 = a required file is missing.

Usage:
    python3 lib/check_agents_sync.py
    python3 lib/check_agents_sync.py --verbose
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

# The two files must sit next to each other at the workspace root.
# This script lives at <root>/lib/check_agents_sync.py, so the root
# is two levels up.
ROOT = Path(__file__).resolve().parent.parent

CLAUDE_MD = ROOT / "CLAUDE.md"
AGENTS_MD = ROOT / "AGENTS.md"

# Optional: a separate capabilities log that also carries [universal] bullets.
# If your workspace does not use one, the script just skips it.
CAPABILITIES_LOG = ROOT / ".claude" / "context" / "capabilities-log.md"

UNIVERSAL_TAG = "[universal]"

# Required section headers that confirm the files have the right shape.
# Edit these to match the headers used in YOUR workspace.
CLAUDE_REQUIRED_HEADERS = [
    "## Capabilities",
]
AGENTS_REQUIRED_HEADERS = [
    "## Capabilities",
    "## Identity",
]


def extract_universal_bullets(text: str) -> list[str]:
    """Return 60-char fingerprints for every [universal]-tagged bullet.

    A bullet qualifies when the list marker is followed by [universal]
    (plain text or backtick-quoted). The fingerprint is the first 60
    characters of the body after the tag is stripped, with runs of
    whitespace collapsed to single spaces.

    60 characters is long enough to be unique across a normal workspace
    but short enough to survive minor trailing edits without false alarms.
    """
    out = []
    for line in text.splitlines():
        stripped = line.strip()
        # Must be a markdown list bullet.
        if not stripped.startswith("- "):
            continue
        body = stripped[2:].strip()

        # Handle both `[universal]` (backtick-quoted) and [universal] (plain).
        if body.startswith("`[universal]`"):
            # Strip the backtick-quoted tag: "`[universal]` rest"
            body = body[len("`[universal]`"):].lstrip("` ").strip()
        elif body.startswith(UNIVERSAL_TAG):
            body = body[len(UNIVERSAL_TAG):].lstrip(" :-").strip()
        else:
            continue

        fingerprint = re.sub(r"\s+", " ", body)[:60].strip()
        if fingerprint:
            out.append(fingerprint)
    return out


def check_headers(
    text: str,
    filename: str,
    required: list[str],
    errors: list[str],
) -> None:
    """Append an error for each required header that is absent from text."""
    for header in required:
        if header not in text:
            errors.append(f"{filename}: missing expected section header '{header}'")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="print every check result, not just failures",
    )
    args = parser.parse_args()

    errors: list[str] = []

    # File existence check first -- nothing else is meaningful without them.
    if not CLAUDE_MD.exists():
        print(f"ERROR: {CLAUDE_MD} not found", file=sys.stderr)
        return 2
    if not AGENTS_MD.exists():
        print(f"ERROR: {AGENTS_MD} not found -- create it to enable cross-agent portability", file=sys.stderr)
        return 2

    claude_text = CLAUDE_MD.read_text()
    agents_text = AGENTS_MD.read_text()
    cap_log_text = CAPABILITIES_LOG.read_text() if CAPABILITIES_LOG.exists() else ""

    # 1. Section header sanity -- catches truncated or wrongly structured files.
    check_headers(claude_text, "CLAUDE.md", CLAUDE_REQUIRED_HEADERS, errors)
    check_headers(agents_text, "AGENTS.md", AGENTS_REQUIRED_HEADERS, errors)

    # 2. Mirror check: every [universal] bullet in CLAUDE.md must appear in AGENTS.md.
    #    Also checks the optional capabilities log if it exists.
    claude_universals = extract_universal_bullets(claude_text)
    log_universals = extract_universal_bullets(cap_log_text)

    # Deduplicate while preserving order (a bullet can appear in both files).
    seen: set[str] = set()
    all_universals: list[str] = []
    for fp in claude_universals + log_universals:
        if fp not in seen:
            seen.add(fp)
            all_universals.append(fp)

    missing: list[str] = []
    for fp in all_universals:
        if fp not in agents_text:
            missing.append(fp)

    if missing:
        for fp in missing:
            errors.append(f"AGENTS.md: missing [universal] mirror for: {fp!r}")
    elif args.verbose:
        print(f"OK: all {len(all_universals)} [universal] bullet(s) are mirrored in AGENTS.md")

    # 3. Size hint: warn if CLAUDE.md is getting large (reader load, not a hard limit).
    claude_size = CLAUDE_MD.stat().st_size
    agents_size = AGENTS_MD.stat().st_size
    SIZE_WARN = 35_000  # bytes; adjust to suit your workspace
    if claude_size > SIZE_WARN:
        errors.append(
            f"CLAUDE.md is {claude_size:,} bytes, over the {SIZE_WARN:,}-byte soft cap. "
            "Consider moving detailed bullets to a capabilities log."
        )
    elif args.verbose:
        print(f"OK: CLAUDE.md is {claude_size:,} bytes (under {SIZE_WARN:,}-byte cap)")

    # Report results.
    if errors:
        print(f"\n{len(errors)} issue(s) found:\n", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
        return 1

    print("CLAUDE.md <-> AGENTS.md sync: clean")
    print(f"  CLAUDE.md : {claude_size:,} bytes")
    print(f"  AGENTS.md : {agents_size:,} bytes")
    print(f"  [universal] bullets tracked: {len(all_universals)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
