# send_gate.py

A human-in-the-loop approval gate for any outbound action your Claude Code
workspace might take: sending email, posting to social, hitting a payment API,
or calling any webhook that has real-world consequences.

## Why this exists

One wrong send to a real customer costs more than a year of token savings. A
Claude Code agent that can reach external APIs without a human checkpoint is a
support ticket waiting to happen. This gate makes it structurally impossible
for an outbound action to fire without a human reading the full payload and
typing an exact confirmation phrase.

## How it works

1. Before any outbound action, your send function calls
   `consume_approval(action_kind, target, payload, workspace_root)`.
2. That returns True only if a valid, fresh, unexpired approval token exists
   on disk for that exact (action_kind, target, payload) triple.
3. Tokens are written only by `request_approval(...)`, which requires a human
   in an interactive terminal to read the full payload and type
   `APPROVE <ACTION_KIND>` verbatim.
4. Each token is single-use: the file is deleted the moment it is consumed.
5. Tokens expire after 5 minutes whether consumed or not.
6. The token filename is a sha256 of (action_kind, target, payload). Editing
   any of those three fields after approval produces a different hash, so the
   old token does not match and the action is blocked.

Nothing in this file touches the network. No third-party libraries. Stdlib only.

## Token storage

Tokens are stored at:

```
<workspace_root>/.claude/.action-approval/<sha256>
```

Add this to your `.gitignore`:

```
.claude/.action-approval/
```

Token files contain the kind and target in plain text so you can inspect them
manually (`cat .claude/.action-approval/*`). The hash-based filename is what
the gate actually checks, not the file contents.

## Integration contract

Your send function must refuse unless `consume_approval` returns True:

```python
from lib.send_gate import consume_approval, block_message

WORKSPACE = Path(__file__).resolve().parents[2]  # adjust to your layout

def send_email(to: str, subject: str, body: str) -> None:
    payload = f"Subject: {subject}\n\n{body}"
    if not consume_approval("EMAIL", to, payload, WORKSPACE):
        raise RuntimeError(block_message("EMAIL", to, WORKSPACE))
    # safe to send now
    _actually_send(to, subject, body)
```

Then, before running the script that calls `send_email`, run the approval step
in an interactive terminal:

```python
from lib.send_gate import request_approval

approved = request_approval("EMAIL", to, payload, WORKSPACE, label="welcome email")
if approved:
    send_email(to, subject, body)
```

The same pattern works for any action kind:

```python
# Social post
consume_approval("POST", "@myhandle", post_text, WORKSPACE)

# Payment
consume_approval("PAYMENT", "stripe:cus_abc123", json.dumps(charge_params), WORKSPACE)

# Outbound webhook
consume_approval("WEBHOOK", "https://api.example.com/notify", json.dumps(body), WORKSPACE)
```

## Install

No install required. Copy `send_gate.py` into your `lib/` folder and import it.

```
your-workspace/
  lib/
    send_gate.py   <-- this file
  scripts/
    send_welcome.py
```

## Quick test (30 seconds)

Run the built-in demo in an interactive terminal:

```bash
python lib/send_gate.py
```

You will see a fake email payload. Type `APPROVE EMAIL` to authorize it. The
demo then confirms the token was consumed and proves a second call returns False.
