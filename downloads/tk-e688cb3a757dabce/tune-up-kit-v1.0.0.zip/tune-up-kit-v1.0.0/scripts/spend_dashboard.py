#!/usr/bin/env python3
"""Spend Dashboard, Workspace Tune-Up Kit component.

Reads your local AI session logs and renders one HTML page: what you spent,
where it went (per day, per model, per project, per skill), how much the cache
saved you, and where the setup falls short. Costs are estimates at list prices.

Reads Claude Code logs (~/.claude/projects) with full cost estimates, and
Codex logs (~/.codex/sessions) as token counts (Codex plans are usually
subscription-priced, so no dollar figure is invented for them).

Everything runs on your machine. No network calls, no AI, no telemetry.

Usage:
    python3 spend_dashboard.py                # last 30 days
    python3 spend_dashboard.py --days 7
    python3 spend_dashboard.py --json         # machine-readable too
    python3 spend_dashboard.py --no-open

Python 3.9+, standard library only.
"""

from __future__ import annotations

import argparse
import html
import json
import sys
import webbrowser
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

VERSION = "1.0.0"
KIT_NAME = "Workspace Tune-Up Kit"

# List prices per million tokens, matched by model-family substring.
# (input, output, cache_write_5m, cache_write_1h, cache_read)
PRICING = [
    ("fable", (10.0, 50.0, 12.5, 20.0, 1.0)),
    ("mythos", (10.0, 50.0, 12.5, 20.0, 1.0)),
    ("opus", (5.0, 25.0, 6.25, 10.0, 0.5)),
    ("sonnet", (3.0, 15.0, 3.75, 6.0, 0.3)),
    ("haiku", (1.0, 5.0, 1.25, 2.0, 0.1)),
]
DEFAULT_PRICE = (5.0, 25.0, 6.25, 10.0, 0.5)  # unknown model: assume opus-tier


def price_for(model: str):
    m = (model or "").lower()
    for family, price in PRICING:
        if family in m:
            return price
    return DEFAULT_PRICE


def usage_cost(model: str, usage: dict) -> float:
    p_in, p_out, p_w5, p_w1h, p_read = price_for(model)
    cost = usage.get("input_tokens", 0) / 1e6 * p_in
    cost += usage.get("output_tokens", 0) / 1e6 * p_out
    cost += usage.get("cache_read_input_tokens", 0) / 1e6 * p_read
    breakdown = usage.get("cache_creation") or {}
    w5 = breakdown.get("ephemeral_5m_input_tokens")
    w1h = breakdown.get("ephemeral_1h_input_tokens")
    if w5 is not None or w1h is not None:
        cost += (w5 or 0) / 1e6 * p_w5
        cost += (w1h or 0) / 1e6 * p_w1h
    else:
        cost += usage.get("cache_creation_input_tokens", 0) / 1e6 * p_w5
    return cost


def short_model(model: str) -> str:
    m = (model or "unknown").lower()
    for family, _ in PRICING:
        if family in m:
            version = ""
            parts = m.split(family)[-1].strip("-").split("-")
            if parts and parts[0].replace(".", "").isdigit():
                version = " " + ".".join(parts[:2]) if len(parts) > 1 and parts[1].isdigit() else " " + parts[0]
            return family.capitalize() + version
    return model or "unknown"


def project_label(slug: str) -> str:
    return slug.split("-")[-1] if slug else slug


# ---------------------------------------------------------------- scanning


def scan_claude(claude_dir: Path, since: datetime) -> dict:
    """Walk ~/.claude/projects/<slug>/*.jsonl, aggregate usage since cutoff."""
    agg = {
        "cost": 0.0,
        "sessions": 0,
        "calls": 0,
        "daily": defaultdict(float),
        "models": defaultdict(lambda: {"cost": 0.0, "in": 0, "out": 0}),
        "projects": defaultdict(float),
        "skills": defaultdict(lambda: {"cost": 0.0, "sessions": 0}),
        "top_sessions": [],
        "tok_uncached": 0,
        "tok_cache_read": 0,
        "tok_cache_write": 0,
        "tok_out": 0,
    }
    if not claude_dir.is_dir():
        return agg
    since_ts = since.timestamp()
    for project_dir in sorted(claude_dir.iterdir()):
        if not project_dir.is_dir():
            continue
        for jsonl in project_dir.glob("*.jsonl"):
            try:
                if jsonl.stat().st_mtime < since_ts:
                    continue
            except OSError:
                continue
            session_cost = 0.0
            session_skills = set()
            session_title = ""
            seen_requests = set()
            try:
                fh = jsonl.open(errors="replace")
            except OSError:
                continue
            with fh:
                for line in fh:
                    if '"assistant"' in line and '"usage"' in line:
                        try:
                            rec = json.loads(line)
                        except (json.JSONDecodeError, ValueError):
                            continue
                        if rec.get("type") != "assistant":
                            continue
                        msg = rec.get("message") or {}
                        # Skill invocations ride on assistant records too.
                        content = msg.get("content") or []
                        if isinstance(content, list):
                            for block in content:
                                if (isinstance(block, dict) and block.get("type") == "tool_use"
                                        and block.get("name") == "Skill"):
                                    skill = (block.get("input") or {}).get("skill")
                                    if skill:
                                        session_skills.add(str(skill))
                        ts = rec.get("timestamp", "")
                        if ts and ts < since.strftime("%Y-%m-%dT%H:%M:%S"):
                            continue
                        usage = msg.get("usage") or {}
                        model = msg.get("model", "")
                        if not usage or model == "<synthetic>":
                            continue
                        # One API response can log several assistant records
                        # (one per content block) sharing requestId + usage.
                        key = rec.get("requestId") or msg.get("id") or rec.get("uuid")
                        if key in seen_requests:
                            continue
                        seen_requests.add(key)
                        model = msg.get("model", "")
                        cost = usage_cost(model, usage)
                        session_cost += cost
                        agg["calls"] += 1
                        agg["daily"][ts[:10]] += cost
                        m = agg["models"][short_model(model)]
                        m["cost"] += cost
                        m["in"] += usage.get("input_tokens", 0)
                        m["out"] += usage.get("output_tokens", 0)
                        agg["tok_uncached"] += usage.get("input_tokens", 0)
                        agg["tok_cache_read"] += usage.get("cache_read_input_tokens", 0)
                        agg["tok_cache_write"] += usage.get("cache_creation_input_tokens", 0)
                        agg["tok_out"] += usage.get("output_tokens", 0)
                    elif '"Skill"' in line and '"tool_use"' in line:
                        try:
                            rec = json.loads(line)
                        except (json.JSONDecodeError, ValueError):
                            continue
                        content = (rec.get("message") or {}).get("content") or []
                        if isinstance(content, list):
                            for block in content:
                                if (isinstance(block, dict) and block.get("type") == "tool_use"
                                        and block.get("name") == "Skill"):
                                    skill = (block.get("input") or {}).get("skill")
                                    if skill:
                                        session_skills.add(str(skill))
                    elif '"ai-title"' in line and not session_title:
                        try:
                            session_title = json.loads(line).get("aiTitle", "")
                        except (json.JSONDecodeError, ValueError):
                            pass
            if session_cost > 0:
                agg["cost"] += session_cost
                agg["sessions"] += 1
                agg["projects"][project_label(project_dir.name)] += session_cost
                for skill in session_skills:
                    agg["skills"][skill]["cost"] += session_cost
                    agg["skills"][skill]["sessions"] += 1
                agg["top_sessions"].append({
                    "title": session_title or jsonl.stem[:8],
                    "project": project_label(project_dir.name),
                    "cost": session_cost,
                })
    agg["top_sessions"].sort(key=lambda s: -s["cost"])
    return agg


def scan_codex(codex_dir: Path, since: datetime) -> dict:
    """Codex rollout logs carry cumulative token counts per session.
    Most Codex plans are subscription-priced, so report tokens, not dollars."""
    out = {"sessions": 0, "tokens": 0, "cached": 0}
    if not codex_dir.is_dir():
        return out
    since_ts = since.timestamp()
    for jsonl in codex_dir.rglob("*.jsonl"):
        try:
            if jsonl.stat().st_mtime < since_ts:
                continue
        except OSError:
            continue
        last_info = None
        try:
            fh = jsonl.open(errors="replace")
        except OSError:
            continue
        with fh:
            for line in fh:
                if '"token_count"' not in line or '"info":null' in line:
                    continue
                try:
                    info = (json.loads(line).get("payload") or {}).get("info")
                except (json.JSONDecodeError, ValueError):
                    continue
                if info and info.get("total_token_usage"):
                    last_info = info["total_token_usage"]
        if last_info:
            out["sessions"] += 1
            out["tokens"] += last_info.get("total_tokens", 0)
            out["cached"] += last_info.get("cached_input_tokens", 0)
    return out


# ---------------------------------------------------------------- analysis


def build_flags(agg: dict, days: int) -> list:
    flags = []
    total_in = agg["tok_uncached"] + agg["tok_cache_read"] + agg["tok_cache_write"]
    cache_hit = 100 * agg["tok_cache_read"] / total_in if total_in else 0

    if total_in and cache_hit < 50:
        flags.append({
            "sev": "high",
            "title": "Cache is doing less than half the work",
            "why": f"Only {cache_hit:.0f}% of your input tokens came from cache. Cached "
                   "tokens cost about a tenth of fresh ones, so a low rate means you "
                   "re-pay for the same context over and over. Common causes: timestamps "
                   "or changing text near the top of instruction files.",
        })

    if agg["models"]:
        top_model = max(agg["models"].items(), key=lambda kv: kv[1]["cost"])
        share = 100 * top_model[1]["cost"] / agg["cost"] if agg["cost"] else 0
        premium = any(f in top_model[0].lower() for f in ("opus", "fable", "mythos"))
        if premium and share > 85 and len(agg["models"]) <= 2:
            flags.append({
                "sev": "high",
                "title": "Nearly everything runs on the most expensive model",
                "why": f"{top_model[0]} carries {share:.0f}% of your spend. Some of that "
                       "is judgment work that deserves it. The rest is drafting, file "
                       "churn, and mechanical edits paying premium rates for no reason.",
            })

    if agg["top_sessions"] and agg["cost"] > 0:
        biggest = agg["top_sessions"][0]
        if biggest["cost"] > agg["cost"] * 0.25 and agg["sessions"] > 4:
            flags.append({
                "sev": "med",
                "title": "One session ate a quarter of the budget",
                "why": f"\"{biggest['title']}\" alone cost ${biggest['cost']:.2f}, "
                       f"{100 * biggest['cost'] / agg['cost']:.0f}% of the period total. "
                       "Long sessions that drag their whole history through every step "
                       "are usually the cause.",
            })

    if days >= 14 and agg["daily"]:
        mid = datetime.now().date() - timedelta(days=7)
        recent = sum(c for d, c in agg["daily"].items() if d >= mid.isoformat())
        prior = sum(c for d, c in agg["daily"].items() if d < mid.isoformat())
        prior_weekly = prior / max(1, (days - 7)) * 7
        if prior_weekly > 1 and recent > prior_weekly * 1.5:
            flags.append({
                "sev": "med",
                "title": "Spend is trending up",
                "why": f"Last 7 days: ${recent:.2f}. Weekly average before that: "
                       f"${prior_weekly:.2f}. Worth a look at what changed before it "
                       "becomes the new normal.",
            })
    return flags


# ---------------------------------------------------------------- report


def render_html(agg: dict, codex: dict, flags: list, days: int) -> str:
    date = datetime.now().strftime("%Y-%m-%d")
    total_in = agg["tok_uncached"] + agg["tok_cache_read"] + agg["tok_cache_write"]
    cache_hit = 100 * agg["tok_cache_read"] / total_in if total_in else 0
    per_day = agg["cost"] / days if days else 0
    # what the cache saved: cached reads billed at ~0.1x instead of 1x
    saved = sum(
        agg["tok_cache_read"] / 1e6 * (p[0] - p[4]) * (m["cost"] / agg["cost"])
        for name, m in agg["models"].items()
        for p in [price_for(name)]
    ) if agg["cost"] else 0

    # daily bar chart
    day_items = []
    today = datetime.now().date()
    max_day = max(agg["daily"].values(), default=0) or 1
    for offset in range(days - 1, -1, -1):
        d = (today - timedelta(days=offset)).isoformat()
        cost = agg["daily"].get(d, 0)
        pct = 100 * cost / max_day
        label = d[5:] if days <= 31 else ""
        day_items.append(
            f'<div class="day" title="{d}: ${cost:.2f}">'
            f'<div class="day-fill" style="height:{max(2, pct):.0f}%"></div>'
            f'<span>{label if offset % max(1, days // 10) == 0 else ""}</span></div>'
        )

    def table(rows, headers):
        head = "".join(f"<th>{h}</th>" for h in headers)
        body = "".join(
            "<tr>" + "".join(f"<td>{html.escape(str(c))}</td>" for c in row) + "</tr>"
            for row in rows
        )
        return f"<table><tr>{head}</tr>{body}</table>"

    model_rows = [
        (name, f"${m['cost']:.2f}", f"{100 * m['cost'] / agg['cost']:.0f}%" if agg["cost"] else "0%",
         f"{m['out']:,}")
        for name, m in sorted(agg["models"].items(), key=lambda kv: -kv[1]["cost"])
    ]
    project_rows = [
        (name, f"${cost:.2f}", f"{100 * cost / agg['cost']:.0f}%" if agg["cost"] else "0%")
        for name, cost in sorted(agg["projects"].items(), key=lambda kv: -kv[1])[:8]
    ]
    skill_rows = [
        (f"/{name}", str(s["sessions"]), f"${s['cost']:.2f}")
        for name, s in sorted(agg["skills"].items(), key=lambda kv: -kv[1]["cost"])[:10]
    ]
    burner_rows = [
        (s["title"][:60], s["project"], f"${s['cost']:.2f}")
        for s in agg["top_sessions"][:6]
    ]

    def flag_card(f):
        color = "dot-red" if f["sev"] == "high" else "dot-amber"
        return (f'<div class="flag"><div class="flag-title"><span class="dot {color}"></span>'
                f'{f["title"]}</div><p>{f["why"]}</p></div>')

    flags_html = "\n".join(flag_card(f) for f in flags) or \
        '<p class="all-clear">No spend flags this period. The setup is running lean.</p>'

    codex_html = ""
    if codex["sessions"]:
        codex_html = (
            f'<p class="codex-note">Codex on this machine: {codex["sessions"]} session(s), '
            f'{codex["tokens"]:,} tokens used ({codex["cached"]:,} from cache). Codex plans '
            f'are usually subscription-priced, so no dollar estimate is shown.</p>'
        )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Spend Dashboard | ~${agg["cost"]:.0f} in {days} days</title>
<style>
  :root {{ --cream:#f5f1ee; --esp:#3d2b1f; --coral:#f24b2e; --gold:#c17817;
           --muted:#8b7b6e; --border:#e8e2de; --green:#3a7d44; }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; background:var(--cream); color:var(--esp); line-height:1.6;
         font-family:-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }}
  .wrap {{ max-width:860px; margin:0 auto; padding:44px 24px 80px; }}
  .eyebrow {{ display:inline-block; background:var(--coral); color:#fff; font-size:12px;
             font-weight:600; letter-spacing:.12em; padding:6px 14px; border-radius:3px;
             font-family:ui-monospace, Menlo, monospace; }}
  h1 {{ font-family:Georgia, "Times New Roman", serif; font-size:36px; margin:18px 0 4px; line-height:1.15; }}
  .sub {{ color:var(--muted); font-size:16px; margin:0 0 28px; }}
  h2 {{ font-family:Georgia, serif; font-size:22px; margin:42px 0 14px;
       border-bottom:2px solid var(--coral); padding-bottom:6px; }}
  .cards {{ display:grid; grid-template-columns:repeat(auto-fit, minmax(170px, 1fr)); gap:14px; }}
  .card {{ background:#fff; border:1px solid var(--border); border-radius:10px; padding:18px 20px; }}
  .card b {{ display:block; font-size:30px; font-family:Georgia, serif; }}
  .card span {{ font-size:13px; color:var(--muted); }}
  .chart {{ display:flex; align-items:flex-end; gap:3px; height:140px; background:#fff;
           border:1px solid var(--border); border-radius:10px; padding:16px 16px 24px; }}
  .day {{ flex:1; display:flex; flex-direction:column; justify-content:flex-end; height:100%;
         position:relative; }}
  .day-fill {{ background:var(--coral); border-radius:2px 2px 0 0; min-height:2px; }}
  .day span {{ position:absolute; bottom:-20px; left:50%; transform:translateX(-50%);
              font-size:9px; color:var(--muted); white-space:nowrap; }}
  table {{ width:100%; border-collapse:collapse; background:#fff; border-radius:8px;
          overflow:hidden; font-size:14px; }}
  th {{ text-align:left; background:var(--esp); color:var(--cream); padding:8px 12px; font-weight:600; }}
  td {{ padding:8px 12px; border-top:1px solid var(--border); }}
  .grid2 {{ display:grid; grid-template-columns:1fr 1fr; gap:18px; }}
  @media (max-width:680px) {{ .grid2 {{ grid-template-columns:1fr; }} h1 {{ font-size:28px; }} }}
  .dot {{ display:inline-block; width:16px; height:16px; border-radius:50%; flex-shrink:0; }}
  .dot-red {{ background:var(--coral); }}
  .dot-amber {{ background:var(--gold); }}
  .flag {{ background:#fff; border:1px solid var(--border); border-radius:8px;
          padding:16px 20px; margin:12px 0; }}
  .flag-title {{ font-weight:600; font-size:16px; display:flex; align-items:center; gap:10px; }}
  .flag p {{ margin:8px 0 0; }}
  .all-clear {{ background:#f3f8f1; border:1px solid var(--green); border-radius:8px; padding:16px 20px; }}
  .codex-note {{ font-size:14px; color:var(--muted); }}
  .privacy {{ margin-top:36px; font-size:13px; color:var(--muted);
             border-top:1px solid var(--border); padding-top:14px; }}
</style>
</head>
<body>
<div class="wrap">
  <span class="eyebrow">SPEND DASHBOARD &middot; {date} &middot; LAST {days} DAYS</span>
  <h1>~${agg["cost"]:,.2f} in the last {days} days</h1>
  <p class="sub">Estimated at list prices from your local Claude Code session logs.
  {agg["sessions"]} session(s), {agg["calls"]} model call(s). Nothing left your machine.
  On a subscription plan? Then this is the model time you consumed, not a bill:
  it shows what your plan is worth and where the waste hides.</p>

  <div class="cards">
    <div class="card"><b>${per_day:,.2f}</b><span>per day, average</span></div>
    <div class="card"><b>{cache_hit:.0f}%</b><span>of input tokens served from cache</span></div>
    <div class="card"><b>~${saved:,.0f}</b><span>saved by the cache this period</span></div>
    <div class="card"><b>{agg["tok_out"]:,}</b><span>output tokens generated</span></div>
  </div>

  <h2>Spend per day</h2>
  <div class="chart">{"".join(day_items)}</div>

  <h2>Where it goes</h2>
  <div class="grid2">
    <div><h3>By model</h3>{table(model_rows, ["Model", "Cost", "Share", "Output tok"])}</div>
    <div><h3>By project</h3>{table(project_rows, ["Project", "Cost", "Share"])}</div>
  </div>

  <h2>Top burners (most expensive sessions)</h2>
  {table(burner_rows, ["Session", "Project", "Cost"])}

  <h2>By skill (cost of sessions using each)</h2>
  {table(skill_rows, ["Skill", "Sessions", "Session cost"]) if skill_rows else "<p>No skill invocations found in this period.</p>"}

  <h2>Where this setup falls short</h2>
  {flags_html}
  {codex_html}

  <p class="privacy">All numbers are estimates at public list prices; subscription plans
  bill differently. This page was built from your local session logs by the {KIT_NAME}
  spend dashboard v{VERSION}. No network calls, no telemetry. Re-run it monthly.</p>
</div>
</body>
</html>
"""


# ---------------------------------------------------------------- main


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Spend dashboard from local AI session logs.")
    parser.add_argument("--days", type=int, default=30, help="period to report (default 30)")
    parser.add_argument("--claude-dir", default="~/.claude/projects")
    parser.add_argument("--codex-dir", default="~/.codex/sessions")
    parser.add_argument("--out", default=None, help="report path (default: spend-dashboard.html in cwd)")
    parser.add_argument("--json", action="store_true", help="also print JSON summary")
    parser.add_argument("--no-open", action="store_true")
    args = parser.parse_args(argv)

    since = datetime.now(timezone.utc) - timedelta(days=args.days)
    agg = scan_claude(Path(args.claude_dir).expanduser(), since)
    codex = scan_codex(Path(args.codex_dir).expanduser(), since)
    flags = build_flags(agg, args.days)

    out_path = Path(args.out) if args.out else Path.cwd() / "spend-dashboard.html"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(render_html(agg, codex, flags, args.days))

    total_in = agg["tok_uncached"] + agg["tok_cache_read"] + agg["tok_cache_write"]
    cache_hit = 100 * agg["tok_cache_read"] / total_in if total_in else 0
    print(f"Spend Dashboard: ~${agg['cost']:,.2f} over {args.days} days "
          f"({agg['sessions']} sessions, cache hit {cache_hit:.0f}%)")
    for f in flags:
        print(f"  flag: {f['title']}")
    print(f"  Report: {out_path}")

    if args.json:
        print(json.dumps({
            "version": VERSION, "days": args.days,
            "cost_usd": round(agg["cost"], 2),
            "sessions": agg["sessions"], "calls": agg["calls"],
            "cache_hit_pct": round(cache_hit, 1),
            "models": {k: round(v["cost"], 2) for k, v in agg["models"].items()},
            "projects": {k: round(v, 2) for k, v in
                         sorted(agg["projects"].items(), key=lambda kv: -kv[1])},
            "skills": {k: {"sessions": v["sessions"], "cost": round(v["cost"], 2)}
                       for k, v in agg["skills"].items()},
            "daily": {k: round(v, 2) for k, v in sorted(agg["daily"].items())},
            "codex": codex,
            "flags": [{"sev": f["sev"], "title": f["title"]} for f in flags],
        }, indent=2))

    if not args.no_open:
        webbrowser.open(out_path.resolve().as_uri())
    return 0


if __name__ == "__main__":
    sys.exit(main())
