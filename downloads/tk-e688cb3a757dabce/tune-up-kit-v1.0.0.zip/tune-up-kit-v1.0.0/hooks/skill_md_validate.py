#!/usr/bin/env python3
"""
PostToolUse hook -- validate a SKILL.md right after it is written.

NON-BLOCKING. Always exits 0. Prints errors and warnings to stderr once per
session per skill so the AI gets a nudge, but the write still stands.

This is the always-on gate that catches a hand-written SKILL.md that skips
your normal authoring flow. Without it, broken frontmatter sits silently until
the AI fails to pick up the skill.

Reads JSON from stdin (Claude Code standard PostToolUse format):
  { "tool_name": "Write"|"Edit"|"MultiEdit", "tool_input": { "file_path": "..." } }

Runs the validator on the file as it exists on disk (PostToolUse fires after
the write), so Write, Edit, and MultiEdit are all handled the same way.

Per-session dedup: the same skill is not re-flagged on every incremental edit.
The dedupe state lives in a temp file keyed by the Claude transcript path so it
resets automatically when a new session starts.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path

# Find the repo root (two levels up from this hooks/ file) and add lib/ to the
# module search path so we can import validate_skill.
REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "lib"))


def _session_state_path() -> Path:
    """Return a temp-file path that is unique to the current Claude session."""
    transcript = os.environ.get("CLAUDE_TRANSCRIPT_PATH", "")
    h = hashlib.sha1(transcript.encode()).hexdigest()[:12] if transcript else "default"
    tmp = Path(os.environ.get("TMPDIR", "/tmp"))
    return tmp / f"skill_md_validate_{h}.json"


def _load_seen(path: Path) -> set[str]:
    try:
        return set(json.loads(path.read_text()))
    except Exception:
        return set()


def _save_seen(path: Path, seen: set[str]) -> None:
    try:
        path.write_text(json.dumps(sorted(seen)))
    except Exception:
        pass


def main() -> int:
    try:
        event = json.load(sys.stdin)
    except Exception:
        return 0

    file_path = (event.get("tool_input") or {}).get("file_path", "")
    if not file_path or not file_path.endswith("SKILL.md"):
        return 0

    p = Path(file_path)
    # Only validate skills under .claude/skills/ -- skip client sandboxes,
    # vendored submodules, and any other SKILL.md files this hook should not touch.
    if ".claude/skills/" not in str(p):
        return 0

    skill_dir = p.parent
    try:
        import validate_skill  # noqa: E402
        result = validate_skill.validate(skill_dir)
    except Exception:
        return 0  # never break the session on a validator bug

    if result["ok"] and not result["warnings"]:
        return 0

    # Dedup per session per skill -- do not nag on every incremental edit.
    state_path = _session_state_path()
    seen = _load_seen(state_path)
    key = result["slug"]
    if key in seen and result["ok"]:
        return 0  # already nudged this clean-but-warned skill this session
    seen.add(key)
    _save_seen(state_path, seen)

    lines = []
    if not result["ok"]:
        lines.append(f"[skill-validate] {result['slug']} SKILL.md has frontmatter errors:")
        for e in result["errors"]:
            lines.append(f"  error:   {e}")
        lines.append(
            "  Fix at the source -- run: python3 lib/validate_skill.py "
            f".claude/skills/{result['slug']} --fail-on-error"
        )
    else:
        lines.append(f"[skill-validate] {result['slug']} SKILL.md is valid but has warnings:")
    for w in result["warnings"]:
        lines.append(f"  warning: {w}")

    print("\n".join(lines), file=sys.stderr)
    return 0  # always exit 0 -- this hook is non-blocking


if __name__ == "__main__":
    sys.exit(main())
