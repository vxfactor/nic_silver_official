#!/usr/bin/env python3
"""
PreToolUse Hook -- Surface security anti-patterns in proposed Write/Edit/MultiEdit content.

Behavior:
  - NON-BLOCKING for pattern nudges. Prints a one-time warning per session per file
    and exits 0 (lets the edit proceed).
  - ONE BLOCKING exception: edits to .mcp.json that introduce an unpinned npx/uvx
    server exit 2 unless a fresh skill-vet approval token exists.

Reads JSON from stdin:
  { "tool_name": "Write" | "Edit" | "MultiEdit",
    "tool_input": { "file_path": "...", "content" | "new_string" | "edits": ... } }

Session state (to suppress repeated warnings) is persisted in a tmp file keyed by
process group. It is automatically discarded when the Claude Code session ends.

Drop this file in .claude/hooks/ and wire it into .claude/settings.json.
See the README in this directory for exact JSON.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable


# ---------------------------------------------------------------------------
# Pattern catalog.
# Each pattern fires only on matching file suffixes (empty tuple = any file).
# On a hit the hook prints the remediation text and exits 0 (non-blocking),
# once per session per (pattern, file) pair.
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Pattern:
    name: str
    suffixes: tuple[str, ...]  # empty = match all file types
    regex: re.Pattern
    remediation: str


PATTERNS: tuple[Pattern, ...] = (
    # Python -- execution from data
    Pattern(
        "python_eval",
        (".py",),
        re.compile(r"^[^#\n]*\beval\s*\(", re.MULTILINE),
        "eval() executes any string as Python. If you need to parse JSON, use json.loads. If you need a small DSL, write a parser.",
    ),
    Pattern(
        "python_exec",
        (".py",),
        re.compile(r"^[^#\n]*\bexec\s*\(", re.MULTILINE),
        "exec() executes any string as Python. Almost never necessary in application code.",
    ),
    Pattern(
        "python_os_system",
        (".py",),
        re.compile(r"^[^#\n]*\bos\.system\s*\(", re.MULTILINE),
        "os.system() runs through the shell. Use subprocess.run([...], shell=False) with an args list.",
    ),
    Pattern(
        "python_shell_true",
        (".py",),
        re.compile(r"\bsubprocess\.\w+\([^)]*\bshell\s*=\s*True", re.DOTALL),
        "subprocess(..., shell=True) is vulnerable to shell injection. Pass an args list and omit shell=True.",
    ),
    Pattern(
        "python_pickle_load",
        (".py",),
        re.compile(r"\bpickle\.(?:load|loads)\s*\("),
        "pickle.load deserializes arbitrary Python including code. Use json or msgpack for untrusted data.",
    ),
    Pattern(
        "python_yaml_load",
        (".py",),
        re.compile(r"\byaml\.load\s*\((?![^)]*Loader\s*=\s*yaml\.SafeLoader)"),
        "yaml.load without SafeLoader can construct arbitrary objects. Use yaml.safe_load instead.",
    ),
    Pattern(
        "python_requests_verify_false",
        (".py",),
        re.compile(r"\b(?:requests|httpx)\.\w+\([^)]*\bverify\s*=\s*False"),
        "verify=False disables TLS certificate checks. Fix the cert chain instead of disabling verification.",
    ),
    # JavaScript / TypeScript -- execution from data
    Pattern(
        "js_eval",
        (".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"),
        re.compile(r"(?<!\w)eval\s*\("),
        "eval() executes any string as JavaScript. Use JSON.parse for data, or a real parser for DSLs.",
    ),
    Pattern(
        "js_function_ctor",
        (".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"),
        re.compile(r"\bnew\s+Function\s*\("),
        "new Function(...) is eval by another name. Replace with a real parser or precompiled logic.",
    ),
    Pattern(
        "js_exec",
        (".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"),
        re.compile(r"\bchild_process\b[^;\n]*\.exec\s*\("),
        "child_process.exec runs through the shell. Use execFile(file, args) or spawn(file, args) with an args list.",
    ),
    # XSS surfaces
    Pattern(
        "react_dangerously_set_inner_html",
        (".jsx", ".tsx"),
        re.compile(r"\bdangerouslySetInnerHTML\b"),
        "dangerouslySetInnerHTML injects raw HTML into the DOM. Sanitize with DOMPurify, or avoid HTML interpolation.",
    ),
    Pattern(
        "dom_inner_html_assign",
        (".js", ".jsx", ".ts", ".tsx", ".html"),
        re.compile(r"\.\s*innerHTML\s*="),
        "element.innerHTML = ... evaluates HTML. Use textContent for plain text, or sanitize the input first.",
    ),
    Pattern(
        "document_write",
        (".js", ".jsx", ".ts", ".tsx", ".html"),
        re.compile(r"\bdocument\.write(?:ln)?\s*\("),
        "document.write is XSS-prone and blocks parsing. Use DOM APIs (createElement + textContent) instead.",
    ),
    # Hardcoded credentials (nudge only -- a dedicated secret scanner is the real gate)
    Pattern(
        "hardcoded_secret_shape",
        (),  # any file type
        re.compile(
            r"\b(?:"
            r"sk-ant-(?:api|admin|train)[0-9a-zA-Z\-_]{20,}|"
            r"sk-proj-[A-Za-z0-9_\-]{32,}|"
            r"sk_live_[A-Za-z0-9]{20,}|"
            r"gh[opsu]_[A-Za-z0-9]{36,}|"
            r"AKIA[0-9A-Z]{16}|"
            r"AIza[0-9A-Za-z\-_]{35}"
            r")\b"
        ),
        "Looks like a real credential in source. Move it to .env and reference by name.",
    ),
)


# ---------------------------------------------------------------------------
# Session state -- once-per-session-per-pattern dedup.
# Suppresses repeated warnings for the same pattern on the same file.
# ---------------------------------------------------------------------------

def _state_path() -> Path:
    """Per-session state file under TMPDIR, keyed by process group."""
    tmp_root = Path(os.environ.get("TMPDIR", "/tmp"))
    session_marker = os.environ.get("CLAUDE_SESSION_ID") or os.environ.get("PPID") or str(os.getppid())
    digest = hashlib.sha1(session_marker.encode()).hexdigest()[:12]
    return tmp_root / f"security_check_{digest}.json"


def _load_seen() -> dict:
    p = _state_path()
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text())
    except Exception:
        return {}


def _save_seen(seen: dict) -> None:
    try:
        _state_path().write_text(json.dumps(seen))
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Content extraction -- pulls the text-to-be-written from the tool input.
# ---------------------------------------------------------------------------

def _extract_content(tool_name: str, tool_input: dict) -> tuple[str, str]:
    """Return (file_path, content_to_inspect). Handles Write, Edit, MultiEdit."""
    file_path = tool_input.get("file_path") or ""
    if tool_name == "Write":
        return file_path, tool_input.get("content") or ""
    if tool_name == "Edit":
        return file_path, tool_input.get("new_string") or ""
    if tool_name == "MultiEdit":
        chunks = []
        for edit in tool_input.get("edits") or []:
            chunks.append(edit.get("new_string") or "")
        return file_path, "\n".join(chunks)
    return file_path, ""


# ---------------------------------------------------------------------------
# MCP config gate -- the one BLOCKING check in this hook.
#
# Writing an unpinned npx/uvx server into .mcp.json bypasses the Bash
# quarantine gate in guardrail_check.py. This gate closes that bypass.
# Exit 2 unless a fresh skill-vet approval token exists.
#
# DEPENDENCY: This gate works alongside skill_vet.py (ships in the Workspace
# Tune-Up Kit). If you are not using skill-vet, you can disable this gate by
# setting PROTECTED_MCP_GATE = False below.
# ---------------------------------------------------------------------------
PROTECTED_MCP_GATE = True  # Set to False to disable

WORKSPACE = Path(__file__).resolve().parents[2]
VET_APPROVAL_DIR = WORKSPACE / "active" / ".vet-approval"
VET_TTL_SECONDS = 300


def _has_unpinned_server(content: str) -> bool:
    """True if the content defines an npx/uvx MCP server without an exact version pin."""
    try:
        data = json.loads(content)
        servers = data.get("mcpServers", {}) if isinstance(data, dict) else {}
        for spec in servers.values():
            if not isinstance(spec, dict):
                continue
            full = " ".join([spec.get("command", "")] + [str(a) for a in spec.get("args", [])])
            if "npx" in full and not re.search(r"@\d[\w.\-]*", full):
                return True
            if "uvx" in full and not re.search(r"==\d", full):
                return True
        return False
    except (ValueError, AttributeError):
        # Partial edit fragment -- fall back to a text check.
        if "npx" in content and not re.search(r"@\d[\w.\-]*", content):
            return True
        if "uvx" in content and not re.search(r"==\d", content):
            return True
        return False


def _any_fresh_vet_token() -> bool:
    """Hook-level signal only. skill_vet.py install does the precise tree-hash check."""
    import time
    try:
        if not VET_APPROVAL_DIR.exists():
            return False
        now = time.time()
        return any(
            p.is_file() and (now - p.stat().st_mtime) <= VET_TTL_SECONDS
            for p in VET_APPROVAL_DIR.iterdir()
        )
    except OSError:
        return False


def check_mcp_config_edit(file_path: str, content: str) -> str | None:
    """Return a block reason if this edit adds an unpinned MCP server without a vet token."""
    if not PROTECTED_MCP_GATE:
        return None
    if not file_path.endswith(".mcp.json"):
        return None
    if not _has_unpinned_server(content):
        return None
    if _any_fresh_vet_token():
        return None
    return (
        "BLOCKED: this edit adds an unpinned npx/uvx MCP server to an .mcp.json. "
        "Unpinned servers auto-run the latest registry version, which is a supply-chain risk. "
        "Either pin an exact version (pkg@x.y.z for npx, pkg==x.y.z for uvx) or vet the "
        "server through skill_vet.py first. A fresh token in active/.vet-approval/ will "
        "unlock this edit."
    )


# ---------------------------------------------------------------------------
# Pattern matching
# ---------------------------------------------------------------------------

def check_content(file_path: str, content: str) -> list[Pattern]:
    """Return the patterns that fire on this content for this file path."""
    if not content:
        return []
    suffix = Path(file_path).suffix.lower() if file_path else ""
    hits: list[Pattern] = []
    for pat in PATTERNS:
        if pat.suffixes and suffix not in pat.suffixes:
            continue
        if pat.regex.search(content):
            hits.append(pat)
    return hits


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    try:
        raw = sys.stdin.read()
        if not raw:
            sys.exit(0)
        data = json.loads(raw)
    except Exception:
        sys.exit(0)  # never break the workflow

    tool_name = data.get("tool_name") or ""
    if tool_name not in {"Write", "Edit", "MultiEdit"}:
        sys.exit(0)

    file_path, content = _extract_content(tool_name, data.get("tool_input") or {})
    if not content:
        sys.exit(0)

    # Skip the hook itself and security rule files (they contain the patterns as literal text).
    abs_path = (file_path or "").lower()
    if any(skip in abs_path for skip in (
        ".claude/rules/security",
        ".claude/hooks/security_check.py",
        "secret_scan.py",
    )):
        sys.exit(0)

    # Blocking gate first (the only exit-2 path in this hook).
    block_reason = check_mcp_config_edit(file_path, content)
    if block_reason:
        print(block_reason)
        sys.exit(2)

    hits = check_content(file_path, content)
    if not hits:
        sys.exit(0)

    seen = _load_seen()
    new_hits: list[Pattern] = []
    for pat in hits:
        key = f"{pat.name}::{file_path}"
        if key in seen:
            continue
        seen[key] = True
        new_hits.append(pat)
    _save_seen(seen)

    if not new_hits:
        sys.exit(0)

    # Emit non-blocking warnings (exit 0 -- the edit is allowed to proceed).
    print("security-check: anti-pattern(s) detected (non-blocking, once per session per file):")
    for pat in new_hits:
        print(f"  [{pat.name}] {pat.remediation}")
    sys.exit(0)


if __name__ == "__main__":
    main()
