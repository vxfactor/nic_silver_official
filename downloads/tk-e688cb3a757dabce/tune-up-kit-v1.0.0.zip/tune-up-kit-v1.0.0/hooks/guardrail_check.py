#!/usr/bin/env python3
"""
PreToolUse Hook -- Block dangerous commands before execution.
Exit 0 = allow. Exit 2 = block (reason printed to stdout, shown to the user).

Drop this file in .claude/hooks/ and wire it into .claude/settings.json.
See the README in this directory for exact JSON.
"""
import json
import re
import sys
import time
from pathlib import Path


# ---------------------------------------------------------------------------
# Blocked command patterns.
# These patterns are matched case-insensitively against the full command string.
# Any match exits 2 and prints the reason.
# ---------------------------------------------------------------------------
BLOCKED_PATTERNS = [
    "rm -rf /",
    "rm -rf ~",
    "rm -rf .",
    "git push --force",
    "git push -f",
    "git reset --hard",
    "DROP TABLE",
    "DROP DATABASE",
    "DELETE FROM",
]


# ---------------------------------------------------------------------------
# Protected paths.
# An rm or delete command that touches any of these paths is blocked.
# Add your own sensitive folders and files here.
# ---------------------------------------------------------------------------
PROTECTED_PATHS = [
    ".env",
    "credentials.json",
    "token.json",
    "CLAUDE.md",
    "AGENTS.md",
    ".claude/",
    ".git/",
    # Add more paths here, e.g.:
    # "clients/",
    # "second-brain/",
    # "delivery/",
]


# ---------------------------------------------------------------------------
# Exfiltration guard.
# Blocks obvious patterns where a tool reads a local file and pipes it to a
# network command. This is defense-in-depth against prompt-injection attacks
# that try to steal secrets by running curl against an attacker's server.
#
# Add your own trusted hosts to EXFIL_ALLOWLIST_HOSTS if you need to upload
# to a host that gets blocked (e.g. your own API endpoint).
# ---------------------------------------------------------------------------
EXFIL_ALLOWLIST_HOSTS = (
    "127.0.0.1",
    "localhost",
    "github.com",
    "raw.githubusercontent.com",
    "api.github.com",
    "registry.npmjs.org",
    "pypi.org",
    "files.pythonhosted.org",
)

# curl/wget that uploads a file body via @path
EXFIL_FILE_UPLOAD_RE = re.compile(
    r"\b(?:curl|wget)\b[^|;&\n]*(?:--data(?:-binary|-urlencode)?|-d|--form|-F|--upload-file|-T|--post-file)[= ]\s*['\"]?@",
    re.IGNORECASE,
)

# base64 piped into a network command (classic exfil prelude)
EXFIL_BASE64_PIPE_RE = re.compile(
    r"\bbase64\b[^|]*\|\s*(?:curl|wget|nc|netcat|ncat|httpie?)\b",
    re.IGNORECASE,
)

# cat/grep/etc on a .env file piped into a network command
EXFIL_SECRET_PIPE_RE = re.compile(
    r"\b(?:cat|tail|head|grep|awk|sed)\b[^|]*\.env\b[^|]*\|\s*(?:curl|wget|nc|netcat|ncat|httpie?)\b",
    re.IGNORECASE,
)


def _command_targets_allowed_host(cmd: str) -> bool:
    """Return True if every URL in the command points at an allowlisted host."""
    urls = re.findall(r"https?://([^/'\"\s]+)", cmd, re.IGNORECASE)
    if not urls:
        # No URL parsed but a network tool is invoked -- safer to flag.
        return False
    return all(any(host.endswith(allowed) for allowed in EXFIL_ALLOWLIST_HOSTS) for host in urls)


def check_exfiltration(command: str) -> dict:
    """Block outbound POST-with-file-body and base64-pipe-to-network unless host is allowlisted."""
    if EXFIL_BASE64_PIPE_RE.search(command):
        return {
            "allow": False,
            "reason": (
                "BLOCKED: base64 piped into a network command (curl/wget/nc). "
                "This is a common exfiltration pattern. If this is intentional, "
                "split the encode and the upload into two separate steps and run "
                "them interactively."
            ),
        }
    if EXFIL_SECRET_PIPE_RE.search(command):
        return {
            "allow": False,
            "reason": (
                "BLOCKED: .env contents piped into a network command. "
                "Secrets must not leave the host. If you need to send a "
                "config file somewhere, redact it manually first."
            ),
        }
    if EXFIL_FILE_UPLOAD_RE.search(command) and not _command_targets_allowed_host(command):
        return {
            "allow": False,
            "reason": (
                "BLOCKED: curl/wget uploading a local file (@path) to a "
                "non-allowlisted host. Add the host to EXFIL_ALLOWLIST_HOSTS "
                "in guardrail_check.py or confirm the action interactively."
            ),
        }
    return {"allow": True, "reason": ""}


# ---------------------------------------------------------------------------
# Email send guardrail.
# This is an early-deny net that prevents the agent from invoking email-send
# scripts at all unless a safe flag or a fresh approval token is present.
# The precise per-message verification (recipient + subject + body hash) still
# happens inside the send scripts themselves (Layers 1 and 2).
#
# HOW TO CONFIGURE:
#   EMAIL_SEND_SCRIPTS -- names of your send scripts that actually dispatch mail.
#   EMAIL_SAFE_FLAGS   -- CLI flags that mean "do not really send" (dry-run modes).
#   OWNER_EMAIL        -- your own address; --to <this address> is always allowed.
#   APPROVAL_DIR       -- where approval token files land (written by Layer 1/2).
# ---------------------------------------------------------------------------
EMAIL_SEND_SCRIPTS = [
    # Add the filenames of your send scripts here, e.g.:
    # "gmail_send.py",
    # "send_email.py",
]
EMAIL_SAFE_FLAGS = ["--render-only", "--dry-run", "--to-self", "--mode test", "--mode=test"]

# Replace with your own address. --to <OWNER_EMAIL> in the command is always allowed.
OWNER_EMAIL = "you@example.com"

# Approval token directory. The kit's send gate (lib/send_gate.py) writes a
# token here when a human approves an outbound action. Same dir, same TTL.
WORKSPACE = Path(__file__).resolve().parents[2]
APPROVAL_DIR = WORKSPACE / ".claude" / ".action-approval"
APPROVAL_TTL_SECONDS = 300


def any_fresh_approval_token() -> bool:
    """Return True if an approval token written in the last TTL seconds exists.

    Used as a hook-level signal only. The send script still verifies the exact
    recipient/subject/body hash before dispatching.
    """
    if not APPROVAL_DIR.exists():
        return False
    now = time.time()
    for p in APPROVAL_DIR.iterdir():
        try:
            if not p.is_file():
                continue
            if (now - p.stat().st_mtime) <= APPROVAL_TTL_SECONDS:
                return True
        except OSError:
            continue
    return False


def check_email_send(command: str) -> dict:
    """Block direct send-script invocations unless a safe flag or approval token is present."""
    if not EMAIL_SEND_SCRIPTS:
        # No send scripts configured -- skip the check.
        return {"allow": True, "reason": ""}

    matched_script = next((s for s in EMAIL_SEND_SCRIPTS if s in command), None)
    if not matched_script:
        return {"allow": True, "reason": ""}

    # Safe flags bypass the block.
    for flag in EMAIL_SAFE_FLAGS:
        if flag in command:
            return {"allow": True, "reason": ""}

    # Sending to your own address is allowed.
    if "--to" in command and OWNER_EMAIL in command:
        return {"allow": True, "reason": ""}

    # A fresh approval token from Layer 1/2 bypasses the block.
    if any_fresh_approval_token():
        return {"allow": True, "reason": ""}

    return {
        "allow": False,
        "reason": (
            f"BLOCKED: '{matched_script}' called without --render-only / --dry-run / "
            f"--to-self / --to {OWNER_EMAIL} and no fresh approval token found in "
            f"{APPROVAL_DIR}.\n"
            f"To send to a real recipient, generate an approval token via your send "
            f"script's interactive mode (it will prompt for confirmation) or run it "
            f"from a TTY."
        ),
    }


# ---------------------------------------------------------------------------
# Quarantine install gate (skill-vet Layer 3 -- early-deny net).
# Blocks copying unvetted third-party code into protected install targets.
# The precise tree-hash verification still happens inside skill_vet.py install.
#
# DEPENDENCY: This gate works alongside skill_vet.py (ships in the Workspace
# Tune-Up Kit). If you are not using skill-vet, you can disable this check by
# leaving PROTECTED_INSTALL_TARGETS empty.
# ---------------------------------------------------------------------------
PROTECTED_INSTALL_TARGETS = (
    ".claude/skills/",
    ".claude/plugins/",
    ".agents/skills/",
    ".mcp.json",
)
INSTALL_VERBS_RE = re.compile(r"\b(?:cp|mv|rsync|ditto|tar|unzip)\b")
QUARANTINE_MARKER = "active/quarantine/"
EXTERNAL_SOURCE_RE = re.compile(r"(?:^|\s)(?:/tmp/|/private/tmp/|~/Downloads/|\$HOME/Downloads/)")
VET_APPROVAL_DIR = WORKSPACE / "active" / ".vet-approval"
VET_TTL_SECONDS = 300


def _fresh_vet_token(slug: str) -> bool:
    """True if skill_vet.py wrote an installable token for <slug> within TTL."""
    token = VET_APPROVAL_DIR / f"{slug}.json"
    try:
        if not token.is_file():
            return False
        if (time.time() - token.stat().st_mtime) > VET_TTL_SECONDS:
            return False
        data = json.loads(token.read_text())
        return data.get("verdict") in ("PASS", "approved_review")
    except (OSError, ValueError):
        return False


def check_quarantine_install(command: str) -> dict:
    """Block moves of unvetted third-party code into install targets."""
    if not PROTECTED_INSTALL_TARGETS:
        return {"allow": True, "reason": ""}

    # skill_vet.py itself is exempt -- its own path is under .claude/skills/,
    # so its scan/approve/install commands would otherwise trip this gate.
    # Only a single unchained invocation is exempt (no ;|&& chaining), so the
    # exemption cannot smuggle a cp/mv on the same line.
    if re.match(r"^\s*(?:python3?\s+)?\S*skill_vet\.py\s", command) and not re.search(r"[;&|]", command):
        return {"allow": True, "reason": ""}

    target_hit = any(t in command for t in PROTECTED_INSTALL_TARGETS)
    if not target_hit:
        return {"allow": True, "reason": ""}

    # git clone straight into an install target -- never allowed.
    if "git clone" in command:
        return {
            "allow": False,
            "reason": (
                "BLOCKED: git clone directly into a protected install target. "
                "Clone into a quarantine folder first: "
                "git clone --depth 1 <url> active/quarantine/<slug>/ "
                "then run skill_vet.py to vet it."
            ),
        }

    # quarantine -> install target: requires a fresh skill-vet approval token.
    if QUARANTINE_MARKER in command:
        m = re.search(r"active/quarantine/([\w.\-]+)", command)
        slug = m.group(1) if m else ""
        if slug and _fresh_vet_token(slug):
            return {"allow": True, "reason": ""}
        return {
            "allow": False,
            "reason": (
                f"BLOCKED: installing '{slug or 'unknown'}' from quarantine without a fresh "
                f"skill-vet approval token in {VET_APPROVAL_DIR}. "
                f"Run skill_vet.py scan -> approve -> install, which also verifies the tree hash."
            ),
        }

    # external source (downloads, /tmp) -> install target: route through quarantine.
    if INSTALL_VERBS_RE.search(command) and EXTERNAL_SOURCE_RE.search(command):
        return {
            "allow": False,
            "reason": (
                "BLOCKED: copying external files (/tmp, ~/Downloads) into a protected "
                "install target. Move the repo to active/quarantine/<slug>/ and vet it "
                "with skill_vet.py first."
            ),
        }

    # workspace-internal moves (authoring, refactors) pass through.
    return {"allow": True, "reason": ""}


# ---------------------------------------------------------------------------
# Main check dispatcher
# ---------------------------------------------------------------------------

def check_command(command: str) -> dict:
    cmd_lower = command.lower().strip()

    for pattern in BLOCKED_PATTERNS:
        if pattern.lower() in cmd_lower:
            return {
                "allow": False,
                "reason": f"BLOCKED: '{pattern}' is a destructive pattern. Ask for explicit confirmation first.",
            }

    for protected in PROTECTED_PATHS:
        if protected in command and ("rm " in cmd_lower or "delete" in cmd_lower):
            return {
                "allow": False,
                "reason": f"BLOCKED: Cannot delete protected path '{protected}'.",
            }

    exfil_check = check_exfiltration(command)
    if not exfil_check["allow"]:
        return exfil_check

    quarantine_check = check_quarantine_install(command)
    if not quarantine_check["allow"]:
        return quarantine_check

    email_check = check_email_send(command)
    if not email_check["allow"]:
        return email_check

    return {"allow": True, "reason": ""}


def main():
    try:
        data = json.loads(sys.stdin.read() or "{}")
        command = data.get("tool_input", {}).get("command", "")
        if not command:
            sys.exit(0)

        result = check_command(command)
        if not result["allow"]:
            print(result["reason"])
            sys.exit(2)

        sys.exit(0)
    except Exception:
        sys.exit(0)  # hooks must never break the workflow


if __name__ == "__main__":
    main()
